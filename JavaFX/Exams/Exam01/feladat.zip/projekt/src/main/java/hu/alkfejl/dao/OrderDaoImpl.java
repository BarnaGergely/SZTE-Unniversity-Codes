package hu.alkfejl.dao;

import hu.alkfejl.config.ContactConfiguration;
import hu.alkfejl.model.Order;

import java.util.ArrayList;
import java.util.List;

import java.sql.*;

public class OrderDaoImpl implements OrderDao{
    private static final String SELECT_ALL_CONTACTS = "SELECT * FROM 'ORDER'";
    private static final String INSERT_CONTACT = "INSERT INTO 'ORDER' (name, type, portion) VALUES (?,?,?)";
    private static final String UPDATE_CONTACT = "UPDATE 'ORDER' SET name=?, type = ?, portion = ? WHERE id=?";
    private static final String DELETE_CONTACT = "DELETE FROM 'ORDER' WHERE id = ?";
    private String connectionURL;

    public OrderDaoImpl() {
        connectionURL = ContactConfiguration.getValue("db.url"); // obtaining DB URL
    }
    @Override
    public Order save(Order order) {
        try(Connection c = DriverManager.getConnection(connectionURL);
            PreparedStatement stmt = order.getId() <= 0 ? c.prepareStatement(INSERT_CONTACT, Statement.RETURN_GENERATED_KEYS) : c.prepareStatement(UPDATE_CONTACT)
        ){
            if(order.getId() > 0){ // UPDATE
                stmt.setInt(4, order.getId());
            }

            stmt.setString(1, order.getName());
            stmt.setString(2, order.getType());
            stmt.setInt(3, order.getPortion());

            int affectedRows = stmt.executeUpdate();
            if(affectedRows == 0){
                return null;
            }

            if(order.getId() <= 0){ // INSERT
                ResultSet genKeys = stmt.getGeneratedKeys();
                if(genKeys.next()){
                    order.setId(genKeys.getInt(1));
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }

        return order;

    }

    @Override
    public List<Order> findAll() {
        List<Order> result = new ArrayList<>();


        try(Connection c = DriverManager.getConnection(connectionURL);
            Statement stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery(SELECT_ALL_CONTACTS)
        ){

            while(rs.next()){
                Order contact = new Order(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("type"),
                        rs.getInt("portion")
                );
                result.add(contact);
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return result;
    }

    @Override
    public boolean delete(int id) {
        try(Connection c = DriverManager.getConnection(connectionURL);
            PreparedStatement stmt = c.prepareStatement(DELETE_CONTACT);
        ) {
            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return true;
    }
}
