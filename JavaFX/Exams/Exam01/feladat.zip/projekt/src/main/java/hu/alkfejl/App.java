package hu.alkfejl;

import hu.alkfejl.dao.OrderDaoImpl;
import hu.alkfejl.model.Order;
import javafx.application.Application;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * JavaFX App
 */
public class App extends Application implements Initializable {


    @FXML
    private static Stage stage;
    @FXML
    private  TableColumn<Order, Number> idCol;
    @FXML
    private TableView<Order> tableView;
    @FXML
    private TableColumn<Order, String> nameCol;
    @FXML
    private TableColumn<Order, String> typeCol;
    @FXML
    private TableColumn<Order, Number> portionCol;
    @FXML
    private TableColumn<Order, String> toolsCol;

    @Override
    public void start(Stage stage) {
        App.stage = stage;
        App.loadFXML("main.fxml");
        stage.show();
    }

    public static FXMLLoader loadFXML(String fxml){

        FXMLLoader loader = new FXMLLoader(App.class.getResource(fxml));
        Scene scene = null;
        try {
            Parent root = loader.load();
            scene = new Scene(root);
        } catch (IOException e) {
            e.printStackTrace();
        }

        stage.setScene(scene);
        return loader;
    }

    public static void main(String[] args) {
        launch();
    }

    public void newOrder(ActionEvent actionEvent) {
        App.loadFXML("newOrder.fxml");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idCol.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getId()));
        nameCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getName()));
        typeCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getType()));
        portionCol.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getPortion()));

        tableView.getItems().setAll(new OrderDaoImpl().findAll());
    }

    public void delete(ActionEvent actionEvent) {
        App.loadFXML("deleteOrder.fxml");
    }
}