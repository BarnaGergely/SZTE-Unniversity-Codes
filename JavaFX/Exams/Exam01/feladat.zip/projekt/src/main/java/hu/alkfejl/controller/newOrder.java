package hu.alkfejl.controller;

import hu.alkfejl.App;
import hu.alkfejl.dao.OrderDaoImpl;
import hu.alkfejl.model.Order;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;

import static java.lang.Integer.parseInt;

public class newOrder implements Initializable {
    @FXML
    private TextField id;
    @FXML
    private ComboBox<String> type;
    @FXML
    private ComboBox<Integer> portion;
    @FXML
    private TextField name;

    public void onClose(ActionEvent actionEvent) {


        App.loadFXML("main.fxml");
    }

    public void onSave(ActionEvent actionEvent) {

        Order order = new OrderDaoImpl().save(new Order(
                !Objects.equals(id.getText(), "") ? parseInt(id.getText()) : -1,
                name.getText(),
                type.getValue(),
                portion.getValue()
        ));
        System.out.println(order.getId());

        App.loadFXML("main.fxml");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ArrayList<String> szoveg = new ArrayList();
        szoveg.add("Sima");
        szoveg.add("Sajtos");
        szoveg.add("Magyaros");
        type.getItems().setAll(szoveg);
        type.getSelectionModel().selectFirst();

        ArrayList<Integer> szam = new ArrayList();
        szam.add(1);
        szam.add(2);
        szam.add(3);
        portion.getItems().setAll(szam);
        portion.getSelectionModel().selectFirst();
    }
}
