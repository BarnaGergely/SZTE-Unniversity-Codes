package hu.alkfejl.dao;

import hu.alkfejl.model.Order;

import java.util.List;

public interface OrderDao {
    Order save(Order order);
    List<Order> findAll();

    boolean delete(int id);
}
