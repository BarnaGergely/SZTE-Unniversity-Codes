package hu.alkfejl.model;

public class Order {
    private int id;
    private String name;
    private String type;
    private int portion;

    public Order(int id, String name, String type, int portion) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.portion = portion;
    }

    public Order(String name, String type, int portion) {
        this.name = name;
        this.type = type;
        this.portion = portion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getPortion() {
        return portion;
    }

    public void setPortion(int portion) {
        this.portion = portion;
    }
}
