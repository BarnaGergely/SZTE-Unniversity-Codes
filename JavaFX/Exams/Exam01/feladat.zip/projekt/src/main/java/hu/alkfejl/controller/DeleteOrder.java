package hu.alkfejl.controller;

import hu.alkfejl.App;
import hu.alkfejl.dao.OrderDaoImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import static java.lang.Integer.parseInt;

public class DeleteOrder {
    @FXML
    private TextField id;

    public void onSave(ActionEvent actionEvent) {
        boolean alma = new OrderDaoImpl().delete(parseInt(id.getText()));
        App.loadFXML("main.fxml");
    }

    public void onClose(ActionEvent actionEvent) {
        App.loadFXML("main.fxml");
    }
}
