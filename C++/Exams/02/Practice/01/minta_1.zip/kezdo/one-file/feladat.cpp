#include <iostream>
#include <string>

//===========================Allat================
class Allat {
  std::string nev;
public:
  Allat( const std::string& nev ) : nev(nev) {}
};


//===========================Gyumolcs===============
class Gyumolcs {
private:
  std::string nev;
  unsigned tapertek;
public:
  Gyumolcs( const std::string& nev, unsigned tapertek ) : nev(nev), tapertek(tapertek) {}
  Gyumolcs() = default;
  bool operator==(const Gyumolcs& masik) const{
    return this->nev == masik.nev && this->tapertek == masik.tapertek;
}
};

//=====================Uj megoldasok==============

