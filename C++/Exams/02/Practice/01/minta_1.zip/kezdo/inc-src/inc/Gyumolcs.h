#pragma once

#include <string>

class Gyumolcs {
private:
  std::string nev;
  unsigned tapertek;
public:
  Gyumolcs( const std::string& nev, unsigned tapertek ) : nev(nev), tapertek(tapertek) {}
  Gyumolcs() = default;
  bool operator==(const Gyumolcs& masik) const;
};
