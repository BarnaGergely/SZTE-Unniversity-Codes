#include "../inc/Gyumolcs.h"

bool Gyumolcs::operator==(const Gyumolcs& masik) const{
    return this->nev == masik.nev && this->tapertek == masik.tapertek;
}