#pragma once

#include <string>
#include "Gyumolcs.h"

class Allat {
  std::string nev;
public:
  Allat( const std::string& nev ) : nev(nev) {}
};
