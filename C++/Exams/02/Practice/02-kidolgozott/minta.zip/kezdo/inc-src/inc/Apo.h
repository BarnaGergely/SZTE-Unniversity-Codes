#pragma once

#include <string>

class Apo {
    std::string nev;
public:
    Apo(const std::string nev) : nev(nev) {}

    ~Apo() {}
};
