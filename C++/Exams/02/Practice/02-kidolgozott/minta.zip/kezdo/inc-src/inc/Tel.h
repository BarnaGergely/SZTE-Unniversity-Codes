#pragma once

#include <string>

class Tel {
    unsigned homerseklet;
    bool meleg;
    unsigned szamlalo = 0;
public:
    Tel(unsigned homerseklet): homerseklet(homerseklet), meleg(false) {
    }

    unsigned get_homerseklet() const;
};
