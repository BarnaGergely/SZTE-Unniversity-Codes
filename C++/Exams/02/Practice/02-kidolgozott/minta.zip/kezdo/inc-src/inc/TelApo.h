#pragma once

#include <iostream>
#include <string>

class TelApo {
    unsigned ajandekok;

public:
    // konstruktorok
};