#include "Tel.h"


unsigned Tel::get_homerseklet() const {
    // szamlalo++;
    return homerseklet;
}

