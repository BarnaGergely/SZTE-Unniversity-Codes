#include <iostream>
#include <string>
#include <exception>
#include <vector>
#include <map>
#include <set>
#include <algorithm>

using namespace std;

// Amelyik reszt szeretned tesztelni, az ne legyen komment
#ifndef TEST_BIRO
    #define PROG_PONT
    #define HAZI
    #define KONYV
    #define KEDVENC_ITAL
#endif

#ifdef PROG_PONT
// 1. FELADAT

// TODO TulKevesPont osztaly helye //

// 2. FELADAT
int jegyek_szama(const map<string, unsigned>& eredmenyek) {
    //TODO megoldas
}
#endif

#ifdef HAZI
#ifndef BIRO_TESTER
// 3. FELADAT
struct Hazi {
    unsigned hazik_szama; // ennyi hazi van a felevben
    unsigned teljesitett_hazik; // ennyi hazit teljesitettunk
};
#endif

void teljesitetteket_kitorol(vector<Hazi>& hazik, float teljesitesi_arany) {
    // TODO megoldas
}
#endif

#ifdef KONYV
#ifndef BIRO_TESTER_KONYV
// 4. FELADAT
struct Konyv {
    int hossz; // a könyv hossza
    string nyelv; // a könyv nyelve

    // TODO < operator
};
#endif

set<Konyv> olvasas(Konyv* konyvek, unsigned meret) {
    // TODO megoldas
}
#endif

#ifdef KEDVENC_TAL
// 5. FELADAT
struct KedvencItal {
    string kinek; // kinek a kedvenc itala
    string mi; // mi a kedvenc itala
};

vector<string> kedvenc_italok(KedvencItal* ital_infok, unsigned darab) {
    // TODO megoldas
}
#endif
