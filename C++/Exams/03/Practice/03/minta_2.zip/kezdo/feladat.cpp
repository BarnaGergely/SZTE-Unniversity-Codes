#include <iostream>
#include <string>
#include "exception"
#include "vector"
#include "map"
#include "set"
#include "algorithm"

using namespace std;

// Amelyik reszt szeretned tesztelni, azt kommentezd ki!
#ifndef TEST_BIRO
  #define NEVHIBA_ES_DIAKOT_KERES
  #define KITOROL
  #define MIKULAST_GYART
  #define FELDOLGOZ
#endif

#ifdef NEVHIBA_ES_DIAKOT_KERES
// 1. Feladat

// NevHiba osztaly helye //

// 2. Feladat
bool diakotKeres(map<string, unsigned> diakok, unsigned keresettKor) {
    // megoldas
    return false; // ezt a sort modosithatod
}
#endif

#ifdef KITOROL
// 3. Feladat
void kitorol(vector<int>& vektor){
    // megoldas
}
#endif

#ifdef MIKULAST_GYART
struct Mikulas {
    unsigned szakallhossz;
    Mikulas(unsigned szakallhossz = 0): szakallhossz(szakallhossz) {}
    // megoldas
};

// 4. Feladat
vector<Mikulas> mikulastGyart(unsigned db, unsigned szakallhossz) {
    // megoldas
    return vector<Mikulas>(); // ezt a sort modosithatod
}
#endif

#ifdef FELDOLGOZ
// 5. Feladat
vector<int> feldolgoz(int* tomb, unsigned tombHossza){
    // megoldas
    return vector<int>(); // ezt a sort modosithatod
}
#endif