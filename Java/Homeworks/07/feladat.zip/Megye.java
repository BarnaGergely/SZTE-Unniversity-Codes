import java.util.ArrayList;
import java.util.List;

public class Megye {
    private String nev;
    private List<Telepules> telepulesek;
    private String web;

    public Megye(String nev) {
        this.nev = nev;
        List<String> telepulesek = new ArrayList<>();
    }

    public boolean ujTelepules(String telepules) {

        return true;
    }
    public void webcimFrissites(String szoveg){

    }
    public void ujLakok(int index, String kerulet, int lakok){

    }
    public int keres(String szoveg){
        return 0;
    }
    public int lakossag(){
        return 0;
    }

    @Override
    public String toString() {
        return  nev+" megye ("+web+")";

    }
}
