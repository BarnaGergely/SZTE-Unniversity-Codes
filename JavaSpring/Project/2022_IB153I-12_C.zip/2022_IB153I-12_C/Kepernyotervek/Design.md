# Design

![image](./Design.jpg)

## Colors

- Blackish: #202020 - szöveg szín
- Dark Grey: #3F3F3F
- Medium Grey: #707070
- Egg Yellow: #FFDF6C - link, gomb szín
- White: #FFFFFF - Háttér elsődleges

## Fonst types

- Body, Footer, Product name, Best products: Kadwa
- Headers, Nav, Banners: Montserrat

## Other

- Corner roundation size: 30
