package application.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ProductList {
    private List<Product> products;

    public ProductList(List<Product> products) {
        this.products = products;
    }

    public List<Product> getProducts() {
        return products;
    }

    public ProductList listProductsById(boolean isReversed){
        Comparator<Product> comparator=Comparator.comparingInt(Product::getId);
        products.sort(isReversed?comparator.reversed():comparator);
        return this;
    }

    public ProductList listProductsByPrice(boolean isReversed){
        Comparator<Product> comparator=Comparator.comparingInt(Product::getPrice);
        products.sort(isReversed?comparator.reversed():comparator);
        return this;
    }

    public ProductList listProductsBySize(boolean isReversed){
        Comparator<Product> comparator=Comparator.comparingInt(Product::getSize);
        products.sort(isReversed?comparator.reversed():comparator);
        return this;
    }

    public ProductList filterBy(String attr, String value){
        List<Product> productscopy=new ArrayList<>(products);
        switch (attr){
            case "name":
                productscopy=productscopy.stream().filter((Product p)-> p.getName().equals(value)).collect(Collectors.toList());
                break;
            case "color":
                productscopy=productscopy.stream().filter((Product p)-> p.getColor().equals(value)).collect(Collectors.toList());
                break;
            default:
                return this;
        }
        return new ProductList(productscopy);
    }

    public ProductList filterBy(String attr, int value, int cmp){
        List<Product> productscopy=new ArrayList<>(products);
        switch (attr){
            case "id":
                productscopy=productscopy.stream().filter((Product p)-> filterHelper(p.getId(), value, cmp)).collect(Collectors.toList());
                break;
            case "price":
                productscopy=productscopy.stream().filter((Product p)-> filterHelper(p.getPrice(), value, cmp)).collect(Collectors.toList());
                break;
            case "size_x":
                productscopy=productscopy.stream().filter((Product p)-> filterHelper(p.getSizeX(), value, cmp)).collect(Collectors.toList());
                break;
            case "size_y":
                productscopy=productscopy.stream().filter((Product p)-> filterHelper(p.getSizeY(), value, cmp)).collect(Collectors.toList());
                break;
            /*case "size_z":
                productscopy=productscopy.stream().filter((Product p)-> filterHelper(p.getSizeZ(), value, cmp)).collect(Collectors.toList());
                break;*/
            default:
                return this;
        }
        return new ProductList(productscopy);
    }

    private boolean filterHelper(int attrvalue, int value, int cmp){
        return Math.signum(cmp)==-1?attrvalue<value:(Math.signum(cmp)==1?attrvalue>value:attrvalue==value);
    }
}
