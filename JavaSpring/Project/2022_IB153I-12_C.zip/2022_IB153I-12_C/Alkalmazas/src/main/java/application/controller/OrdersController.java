package application.controller;

import application.dao.BasketDAO;
import application.dao.OrderDAO;
import application.dao.UserDAO;
import application.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.StringJoiner;

@Controller
public class OrdersController {
    @Autowired
    private OrderDAO orderDAO;

    public static class FrontendOrder { // A rendelések megjelenítéséhez ebbe a class-ba kell eltárolni előfeldolgoznva az adatokat
        public Date time;
        public String status;
        public String buyer; // Vásárlő neve összefűzve (Kiss Pista)
        public String products; // termék mennyisége és neve össze fűzve("6db Telefon, 4db Tablet, ...")

        public FrontendOrder(Date time, String status, String buyer, String products) {
            this.time = time;
            this.status = status;
            this.buyer = buyer;
            this.products = products;
        }
    }

    @RequestMapping("/rendelesek")
    public String index(Model model) {
        ArrayList<FrontendOrder> frontorder = new ArrayList<>();
        ArrayList<Transaction> orders= (ArrayList<Transaction>) orderDAO.getOrders(2);/*TODO: SESSION USER ID*/
        /*nem létező init (így fog kinézni a DAO által visszaadott érték)
        ArrayList<OrderedProduct> prods= new ArrayList<>();
        prods.add(new OrderedProduct("sajt",100,"étel","sajt.png","Szasztok srácok én Sajt32 vagyok.","sárga",1,1,3,64));
        prods.add(new OrderedProduct("kecske",10000,"állat","kecske.png","Goat!","kecskeszín",30,50,70,8));
        prods.add(new OrderedProduct("semmi",0,"nincs","0byte.png","-","átlátszó",0,0,0,65535));
        Basket baskettemp=new Basket(0,prods);
        orders.add(new Transaction(1,new Time(12,24,32),"Aktív",new User("John","Doe","aha","macska","@","00000",40),baskettemp));
        nem létező init vége*/

        for(Transaction transaction: orders){
            StringJoiner products= new StringJoiner(", ");
            for(OrderedProduct orderedProduct:transaction.getBasket().getProducts()){
                products.add(orderedProduct.getQuantity()+"db "+orderedProduct.getName());
            }
            frontorder.add(new FrontendOrder(transaction.getTime(),transaction.getStatus(),transaction.getBuyer().getFirstName()+" "+transaction.getBuyer().getSurName(),products.toString()));
        }

        /* Ezt a részt még megg kell írni, csak az alapjai vannak meg
        UserDAO userDAO = new UserDAO(); //nem tudom hogy kell ezt megcsinálni (user kezelés témaköre)
        BasketDAO basketDAO = new BasketDAO(); // ezt sem tudom hogy kellene csinálni
        TransactionDAO transactionDAO = new TransactionDAO(); // ezt sem tudom hogy kellene csinálni

        for (Transaction transaction : transactionDAO.getTransactions()) {
            User user = userDAO.getUserById(transaction.getBuyer().getId());
            Basket basket = basketDAO.getBasketById(transaction.getBasket().getId());

            orders.add(new Order(transaction.getTime(),
                    transaction.getStatus(),
                    "" + user.getSurName() + user.getFirstName(),
                    "" + basket.toProductString()));
        }

        */

        // Teszt tartalom
        //ordersold.add(new FrontendOrder(new Time(12,24,32), "Aktív", "Kiss Pista", "3db létra, 2db Telefon, 987456db Árvíztűrőtükörfúrógép, "));
        //ordersold.add(new FrontendOrder(new Time(13,24,32), "Aktíve", "Kiss Géza", "4 látra, 2db lefon, 956db Árvíztűkörfúrógép, "));

        model.addAttribute("pageTitle", "Webáruház");
        model.addAttribute("orders", frontorder);
        return "Orders";
    }
}