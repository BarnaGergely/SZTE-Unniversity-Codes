package application.model;
import java.util.ArrayList;
import java.util.List;

public class Basket extends OrderedProduct {
    int id;
    List<OrderedProduct> products;
    int priceSummary;

    public Basket() {}

    public Basket(int id, List<OrderedProduct> products) {
        this.id = id;
        this.products = products;
        this.priceSummary=0;
        for(int i = 0; i < products.size(); i++){
            this.priceSummary += products.get(i).getPrice()*products.get(i).getQuantity();
        }


    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public List<OrderedProduct> getProducts() {
        return products;
    }

    public void setProducts(List<OrderedProduct> products) {
        this.products = products;
    }

    public int getPriceSummary() {
        return priceSummary;
    }

    public void setPriceSummary(int priceSummary) {
        this.priceSummary = priceSummary;
    }

    public String toProductString(){
        String string = "";
        for (OrderedProduct product:
             this.products) {
            string += ""+product.getQuantity()+"db "+product.getName()+", ";
        }
        return ""+string;
    }

    @Override
    public String toString() {
        return "Basket{" +
                "id=" + id +
                ", products=" + products +
                ", price=" + priceSummary +
                '}';
    }
}


