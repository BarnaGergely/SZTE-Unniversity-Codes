package application.controller;

import application.dao.ProductDAO;
import application.model.Product;
import org.springframework.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Controller
public class ProductPageController {

    @Autowired
    ProductDAO productDAO;

    @GetMapping("/termek/{id}")
    public String index(@PathVariable("id") int id, Model model) {
        Product product = productDAO.getProductById(id);
        model.addAttribute("pageTitle", product.getName()+" - Webáruház");
        model.addAttribute("titleH1", product.getName());
        model.addAttribute("image", product.getImage());
        model.addAttribute("X", "Szélesség: "+product.getSizeX()+" cm");
        model.addAttribute("Y", "Hosszúság: "+product.getSizeY()+" cm");
        model.addAttribute("Z", "Magasság: "+product.getSizeZ()+" cm");
        model.addAttribute("color", "Szín: "+product.getColor());
        model.addAttribute("price", "Ár: "+product.getPrice()+" Ft/db");
        model.addAttribute("description", product.getDescription());

        return "ProductPage";
    }

    @GetMapping("/addProduct")
    public String addProduct(Model model) {
        model.addAttribute("pageTitle", "Termék hozzáadás");
        return "ProductAdd";
    }

    @PostMapping(value = "/add")
    public String addProductPage(@RequestParam("productName") String productName, @RequestParam("productPrice") int productPrice, /*@RequestParam("productType") String productType,*/ @RequestParam("fileName") MultipartFile multipartFile, @RequestParam("productDescription") String productDescription, @RequestParam("productColor") String productColor, @RequestParam("productSizeX") int productSizeX, @RequestParam("productSizeY") int productSizeY, @RequestParam("productSizeZ") int productSizeZ) throws IOException {
        String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        Product product = new Product(productName,productPrice,"a",("/Alkalmazas/src/main/resources/images/"+fileName),productDescription,productColor,productSizeX,productSizeY,productSizeZ);
        productDAO.insertProduct(product);
        String uploadDir = "Alkalmazas/src/main/resources/images";
        Path uploadPath = Paths.get(uploadDir);

        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        try (InputStream inputStream = multipartFile.getInputStream()) {
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ioe) {
            throw new IOException("Could not save image file: " + fileName, ioe);
        }
        return "redirect:/katalogus";
    }
    @GetMapping("/updateProduct")
    public String updateProduct(){
        return "productUpdate";
    }
    @PostMapping (value = "/updateProduct/{id}")
    public String updatePproductPage(@PathVariable("id")int id,@RequestParam("productName") String productName, @RequestParam("productPrice") int productPrice,@RequestParam("productType") String productType,@RequestParam("image") MultipartFile multipartFile, @RequestParam("productDescription") String productDescription, @RequestParam("productColor") String productColor, @RequestParam("productSizeX") int productSizeX, @RequestParam("productSizeY") int productSizeY, @RequestParam("productSizeZ") int productSizeZ) throws IOException {
        String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        String uploadDir = "Alkalmazas/src/main/resources/images";
        Path uploadPath = Paths.get(uploadDir);

        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        try (InputStream inputStream = multipartFile.getInputStream()) {
            Path filePath = uploadPath.resolve(fileName);
            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ioe) {
            throw new IOException("Could not save image file: " + fileName, ioe);
        }
        productDAO.updateProduct(id,productName,productPrice,productDescription,("/Alkalmazas/src/main/resources/images/"+fileName),productColor,productSizeX,productSizeY,productSizeX,"a");
        return "redirect:/katalogus";
    }
    @PostMapping (value = "/deleteProduct/{id}")
    public String deleteProduct(@PathVariable("id") int id){
        productDAO.deleteProduct(id);
        return "redirect:/katalogus";
    }
}