package application.dao;

import application.model.Basket;
import application.model.OrderedProduct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class BasketDAO extends JdbcDaoSupport {
    @Autowired
    DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public void insertBasket(int product_id,String userName){
        String sql= "INSERT INTO webshopdb.basket_product(product_id,quantity) VALUES (?,?) WHERE webshop.user.userName=" + userName + " AND webshop.basket.User_userName=webshop.user.userName AND webshop.basket.id=webshop.basket_product.basketid";
        assert getJdbcTemplate() != null;
            getJdbcTemplate().update(sql,product_id,1);
    }

    /*public void updateBasket(int id, int user_id){
        int quantity = 1;
        String sql = "UPDATE webshopdb.basket_product,webshopdb.user,webshopdb.product,webshopdb.basket SET webshop.basket_product.quantity="+quantity+" WHERE product_id="+id + "AND webshop.basket.user_userid=webshop.user.userid AND webshop.basket.user_userid=" +user_id;
        getJdbcTemplate().update(sql);
    }*/
    public void deleteBasketProduct(int id) {
        String sql = "DELETE FROM webshopdb.basket_product WHERE webshopdb.basket_product.id IN (SELECT webshopdb.basket_product.id FROM webshopdb.basket_product,webshopdb.basket WHERE webshopdb.basket_product.product_id=" + id + " AND webshopdb.basket_product.basket_id=webshopdb.basket.id)";
        getJdbcTemplate().update(sql);
    }
    public Basket getBasketById(String userName) {
        String sql = "SELECT * FROM webshopdb.basket_product,webshopdb.product,webshopdb.user,webshopdb.basket WHERE webshopdb.user.userName=? AND webshopdb.basket.user_username=webshopdb.user.username AND webshopdb.basket_product.product_id=webshopdb.product.id";
        //String sql2 = "SELECT Count(*) FROM webshopdb.basket_product,webshopdb.product WHERE webshop.basket_product.basketid=? AND webshop.basket_product.productid=webshopdb.product.id";
        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql,userName);
        //ArrayList<Basket> result = new ArrayList<Basket>();
        //int i = 0;
        Basket basket = new Basket();
        List<OrderedProduct> products = new ArrayList<OrderedProduct>();
        for (Map < String, Object > row: rows) {
            OrderedProduct product = new OrderedProduct();
            basket.setId((Integer) row.get("basket_id"));
            product.setId((Integer) row.get("product_id"));
            product.setName((String) row.get("productName"));
            product.setPrice((int) row.get("productPrice"));
            product.setDescription((String) row.get("productDescription"));
            product.setImage((String) row.get("productIMG"));
            product.setColor((String) row.get("productColor"));
            product.setSizeX((int) row.get("productSizeX"));
            product.setSizeY((int) row.get("productSizeY"));
            product.setSizeZ((int) row.get("productSizeZ"));
            product.setType((String) row.get("productcategory"));
            products.add(product);//.set(i, product);
            //i++;
        }
        basket.setProducts(products);
        //result.add(basket);
        return basket;
    }


}
