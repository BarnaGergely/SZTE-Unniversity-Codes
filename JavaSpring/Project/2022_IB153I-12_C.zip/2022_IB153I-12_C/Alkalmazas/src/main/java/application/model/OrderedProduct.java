package application.model;

public class OrderedProduct extends Product{
    int quantity;

    public OrderedProduct() {
        super();
    }

    public OrderedProduct(String name, int price, String type, String image, String description, String color, int sizeX, int sizeY, int sizeZ, int quantity) {
        super(name, price, type, image, description, color, sizeX, sizeY, sizeZ);
        this.quantity = quantity;
    }

    public OrderedProduct(String name, int price, String type, int id, String image, String description, String color, int sizeX, int sizeY, int sizeZ, int quantity) {
        super(name, price, type, id, image, description, color, sizeX, sizeY, sizeZ);
        this.quantity = quantity;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "OrderedProduct{" +
                "quantity=" + quantity +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", id=" + id +
                ", type='" + type + '\'' +
                ", image='" + image + '\'' +
                ", description='" + description + '\'' +
                ", color='" + color + '\'' +
                ", sizeX=" + sizeX +
                ", sizeY=" + sizeY +
                ", sizeZ=" + sizeZ +
                '}';
    }
}
