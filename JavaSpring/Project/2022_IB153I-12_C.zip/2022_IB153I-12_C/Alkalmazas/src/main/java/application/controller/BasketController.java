package application.controller;

import application.dao.BasketDAO;
import application.model.OrderedProduct;
import application.model.Product;
import application.model.Basket;
import application.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Controller
public class BasketController {

    @Autowired
    BasketDAO basketDao;

    @RequestMapping("/basket")
    public String index(Model model) {
        final String currentUserName = SecurityContextHolder.getContext().getAuthentication().getName();
        if(currentUserName == "anonymousUser"){ // Nem biztos hogy jó, de látszólag működik
            return "redirect:/register_login"; // hibás az átirányítás
        }
        model.addAttribute("pageTitle", "Kosár - Webáruház");
        model.addAttribute("basketItems", getBasket(currentUserName));
        return "basket";
    }

    private List<OrderedProduct> getBasket(String userName) { // Ideiglenes függvény a termékek lekérdezésére. A DAO-ban kell ezt megvalósítani.
        List<OrderedProduct> products;
        Basket basket;
        basket = basketDao.getBasketById(userName);
        products = basket.getProducts();
        return products;
    }

    @PostMapping(value = "/addKosar/{id}")
    public String insertItem(@PathVariable("id") int id) {
        final String currentUserName = SecurityContextHolder.getContext().getAuthentication().getName();
        if(currentUserName == null){ // Nem biztos hogy jó, de látszólag működik
            return "register_login";
        }
        basketDao.insertBasket(id, currentUserName);
        return "redirect:/ProductPage/{" + id + "}";
    }

    @PostMapping(value = "deleteItem/{id}")
    public String deleteItem(@PathVariable("id") int id) {
        basketDao.deleteBasketProduct(id);
        return "redirect:/basket";
    }
    /*@PostMapping(value = "updateQuantity/{id}")
    public void updateQuantity(@PathVariable("id") int id, HttpSession session){
        User user = (User) session.getAttribute("currentSessionUser");

    }*/
}
