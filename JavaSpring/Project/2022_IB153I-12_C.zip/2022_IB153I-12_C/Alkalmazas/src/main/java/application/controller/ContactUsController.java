package application.controller;
import application.dao.ContactDAO;
import application.dao.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import application.dao.ContactDAO;
import application.model.User;
import application.model.Contact;

@Controller
public class ContactUsController {

    @Autowired
    private ContactDAO contactDAO;
    @Autowired
    private UserDAO userDAO;

    @GetMapping("/contactUs")
    public String contactUs(Model model) {
        model.addAttribute("pageTitle", "Kapcsolat");
        return "ContactUs";
    }

    @PostMapping(value = "/{id}/contactAdd")
    public String cintactAdd(@PathVariable("id") int id,@RequestParam("message") String message){
        Contact contact=new Contact(userDAO.getUserById(id).getUsername(),userDAO.getUserById(id).getEmail(),message);
        contactDAO.insertContact(contact);
        return "redirect:/contactUs";
    }
}
