package application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import application.dao.UserDAO;
import application.model.User;

@Controller
public class UserController {

    @Autowired
    private UserDAO userDAO;
    private BCryptPasswordEncoder passwordEncoder;

    @GetMapping("/register_login")
    public String register(Model model) {
        model.addAttribute("pageTitle", "Regisztráció/Belépés");
        return "register_login";
    }

    /*
    @GetMapping(value = "/login")
    public String loginUser() {
        return "login";
    }
    */

    @PostMapping(value = "/registerUser")
    public String registerUser(@RequestParam("username") String username, @RequestParam("surName") String surName, @RequestParam("firstName") String firstName, @RequestParam("password") String password, @RequestParam("email") String email, @RequestParam("phoneNumber") String phoneNumber, @RequestParam("age") int age) {
        User user = new User(firstName,surName,username,password,email,phoneNumber,age);
        userDAO.insertUser(user);
        return "redirect:/register_login";
    }



    @GetMapping("/profile")
    public String profile() {
        return "profile";
    }
    @PostMapping(value = "/updateUser/{id}")
    public String updateUser(@PathVariable("id") int id,@RequestParam("username") String username, @RequestParam("surName") String surName, @RequestParam("firstName") String firstName, @RequestParam("password") String password, @RequestParam("newPassword1") String newPassword1, @RequestParam("newPassword2") String newPassword2, @RequestParam("email") String email, @RequestParam("phoneNumber") String phoneNumber, @RequestParam("age") int age, @RequestParam("country") String country, @RequestParam("city") String city, @RequestParam("zipCode") int zipCode, @RequestParam("address") String address) throws Exception {
            userDAO.updateUser(id,username,password,newPassword1,newPassword2, email, firstName, surName,phoneNumber,  age, country, city, zipCode, address);
        return "redirect:/profile";
    }
    @PostMapping(value = "/deleteUser/{id}")
    public String deleteUser(@PathVariable("id") int id){
        userDAO.deleteUser(id);
        return "redirect:/";
    }

}
