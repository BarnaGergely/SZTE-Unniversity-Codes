package application.dao;

import application.model.Address;
import application.model.Product;
import application.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class ProductDAO extends JdbcDaoSupport {

    @Autowired
    DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public void insertProduct(Product product){
        String sql = "INSERT INTO webshopdb.product(productName, productPrice, productDescription,productIMG, productColor, productSizeX, productSizeY,productSizeZ, productcategory) VALUES (?, ?, ?,?,?,?,?,?,?)";
        getJdbcTemplate().update(sql,new Object[]{
                product.getName(),product.getPrice(),product.getDescription(),product.getImage(),product.getColor(),product.getSizeX(),product.getSizeY(),product.getSizeZ(),product.getType()});
    }
    public void updateProduct(int id,String productName,int productPrice,String productDescription,String image,String productColor,int productSizeX,int productSizeY,int productSizeZ, String productType){
        String sql = "UPDATE webshopdb.product SET productName='"+productName+"', productPrice='"+productPrice+"', productDescription='"+productDescription+"', productIMG='"+image+"', productColor='"+productColor+"', productSizeX='"+productSizeX+"', productSizeY='"+productSizeY+"',productSizeZ='"+productSizeZ+"',productCategory='"+productType+"' WHERE id="+id;
        getJdbcTemplate().update(sql);
    }
    public void deleteProduct(int id) {
        String sql = "DELETE FROM webshopdb.product WHERE id=" + id;
        getJdbcTemplate().update(sql);
    }
    public Product getProductById(int id){
        String sql = "SELECT * FROM webshopdb.product WHERE webshopdb.product.id=?";
        List<Map< String, Object >> rows = getJdbcTemplate().queryForList(sql, id);
        List < Product > result = new ArrayList< Product>();
        for (Map < String, Object > row: rows) {
            Product product = new Product();
            product.setId((Integer) row.get("id"));
            product.setName((String) row.get("productName"));
            product.setPrice((int) row.get("productPrice"));
            product.setDescription((String) row.get("productDescription"));
            product.setImage((String) row.get("productIMG"));
            product.setColor((String) row.get("productColor"));
            product.setSizeX((int) row.get("productSizeX"));
            product.setSizeY((int) row.get("productSizeY"));
            product.setSizeZ((int) row.get("productSizeZ"));
            product.setType((String) row.get("productcategory"));
            result.add(product);
        }
        return result.get(0);
    }

    public ArrayList getProductAll(){
        String sql = "SELECT * FROM webshopdb.product ORDER BY id";
        List<Map< String, Object >> rows = getJdbcTemplate().queryForList(sql);
        ArrayList< Product > result = new ArrayList<Product>();
        for (Map < String, Object > row: rows) {
            Product product = new Product();
            product.setId((Integer) row.get("id"));
            product.setName((String) row.get("productName"));
            product.setPrice((int) row.get("productPrice"));
            product.setDescription((String) row.get("productDescription"));
            product.setImage((String) row.get("productIMG"));
            product.setColor((String) row.get("productColor"));
            product.setSizeX((int) row.get("productSizeX"));
            product.setSizeY((int) row.get("productSizeY"));
            product.setSizeZ((int) row.get("productSizeZ"));
            product.setType((String) row.get("productcategory"));
            result.add(product);
        }
        return result;
    }

}
