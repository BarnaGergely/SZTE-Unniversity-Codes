package application.model;

public class Product {
    String name;
    int price;
    int id;
    String type;
    String image;
    String description;
    String color;
    int sizeX;
    int sizeY;
    int sizeZ;

    public Product(){

    }

    public Product(String name, int price,String type,String image, String description, String color, int sizeX, int sizeY, int sizeZ) {
        this.name = name;
        this.price = price;
        this.description = description;
        this.color = color;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.sizeZ = sizeZ;
        this.image=image;
        this.type=type;
    }

    public Product(String name, int price,String type, int id,String image, String description, String color, int sizeX, int sizeY, int sizeZ) {
        this.name = name;
        this.price = price;
        this.id = id;
        this.description = description;
        this.color = color;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.sizeZ = sizeZ;
        this.image=image;
        this.type=type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getSizeX() {
        return sizeX;
    }

    public void setSizeX(int sizeX) {
        this.sizeX = sizeX;
    }

    public int getSizeY() {
        return sizeY;
    }

    public void setSizeY(int sizeY) {
        this.sizeY = sizeY;
    }

    public int getSizeZ() {
        return sizeZ;
    }

    public void setSizeZ(int sizeZ) {
        this.sizeZ = sizeZ;
    }
    
    public int getSize(){
        return sizeX * sizeY * sizeZ;
    }

    @Override
    public String toString() {
        return "Product{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", id=" + id +
                ", description='" + description + '\'' +
                ", color='" + color + '\'' +
                ", sizeX=" + sizeX +
                ", sizeY=" + sizeY +
                ", sizeZ=" + sizeZ +
                '}';
    }
}
