package application.model;

public class Address {
    String country;
    String city;
    int zipCode;
    String streetHouseNumber;
    public Address(){}

    public Address(String country, String city, int zipCode, String streetHouseNumber) {
        this.country = country;
        this.city = city;
        this.zipCode = zipCode;
        this.streetHouseNumber = streetHouseNumber;
    }

    public String getCountry() {
        return country;
    }

    public String getCity() {
        return city;
    }

    public int getZipCode() {
        return zipCode;
    }

    public String getStreetHouseNumber() {
        return streetHouseNumber;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }

    public void setStreetHouseNumber(String streetHouseNumber) {
        this.streetHouseNumber = streetHouseNumber;
    }
}
