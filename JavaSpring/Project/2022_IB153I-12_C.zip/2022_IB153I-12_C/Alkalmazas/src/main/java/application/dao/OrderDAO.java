package application.dao;

import application.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class OrderDAO extends JdbcDaoSupport {

    @Autowired
    DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }
    public ArrayList<Transaction> getTransactions() { // TODO:
        return new ArrayList<Transaction>();
    }

    public List<Transaction> getOrders(int id){
        String sql = "SELECT * FROM webshopdb.user,webshopdb.product,webshopdb.basket,webshopdb.order,webshopdb.order_basket,webshopdb.basket_product  WHERE webshopdb.user.userid=webshopdb.basket.user_userid AND webshopdb.order.user_userid=webshopdb.user.userid AND webshopdb.basket.id=webshopdb.order.basketid AND webshopdb.basket.id=webshopdb.order_basket.basket_id AND webshopdb.order.id=webshopdb.order_basket.order_id AND webshopdb.basket_product.product_id=webshopdb.product.id AND webshopdb.basket_product.basket_id=webshopdb.basket.id";
        List<Map<String,Object>> rows=getJdbcTemplate().queryForList(sql);
        List<Transaction> result = new ArrayList<>();
        for (Map<String, Object> row: rows) {
            Transaction transaction = new Transaction();
            transaction.setId((Integer) row.get("order_id"));
            transaction.setTime((Date) row.get("orderdate"));
            transaction.setStatus((String) row.get("status"));
            transaction.setBuyer(new User((String) row.get("firstname"),(String) row.get("surename"),(String) row.get("username"),(String) row.get("password"),(String) row.get("email"),(String) row.get("phonenumber"),(Integer) row.get("age")));
            int i;
            boolean talalt=false;
            for (i = 0; i < result.size(); i++) {
                if(result.get(i).getId()==transaction.getId()){talalt=true;break;}
            }
            OrderedProduct op=new OrderedProduct((String) row.get("productname"),(Integer) row.get("productprice"),(String) row.get("productcategory"),
                    (String) row.get("productimg"),(String) row.get("productdescription"),(String) row.get("productcolor"),(Integer) row.get("productsizex"),(Integer) row.get("productsizey"),(Integer) row.get("productsizez"),(Integer) row.get("quantity"));
            if(talalt){
                result.get(i).getBasket().getProducts().add(op);
            } else {
                List<OrderedProduct> orderedProducts=new ArrayList<>();
                orderedProducts.add(op);
                Basket baskettemp=new Basket((Integer) row.get("id"),orderedProducts);
                transaction.setBasket(baskettemp);
                result.add(transaction);
            }


        }
        return result;
    }
}
