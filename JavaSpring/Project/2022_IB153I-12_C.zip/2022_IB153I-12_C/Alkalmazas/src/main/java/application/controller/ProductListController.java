package application.controller;

import application.dao.ProductDAO;
import application.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;

@Controller
public class ProductListController {

    @Autowired
    ProductDAO productDAO;

    @RequestMapping("/katalogus")
    public String index(Model model) {
        model.addAttribute("pageTitle", "Termék neve - Webáruház");
        model.addAttribute("products", getProducts());
        return "ProductList";
    }

    private ArrayList<Product> getProducts() { // Ideiglenes függvény a termékek lekérdezésére. A DAO-ban kell ezt megvalósítani.
        ArrayList<Product> products = new ArrayList<>();
        products = productDAO.getProductAll();
        /*for(Product p : products){
        }*/
        /*Product product1 = new Product();
        product1.setName("Ífóné");
        product1.setPrice(46859);
        product1.setId(1);
        Product product2 = new Product();
        product2.setName("Ífóné2");
        product2.setPrice(35584);
        products.add(product1);
        products.add(product2);*/
        return products;
    }
}
