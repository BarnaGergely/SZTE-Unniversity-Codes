package application.model;

import java.sql.Date;
import java.sql.Time;

public class Transaction {
    int id;
    Date time; // TODO: kitalálni és implementálni, hogy a Date-et is eltárolhassuk
    String status;
    User buyer;
    Basket basket;

    public Transaction() {}

    public Transaction(int id, Date time, String status, User buyer, Basket basket) {
        this.id = id;
        this.time = time;
        this.status = status;
        this.buyer = buyer;
        this.basket = basket;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public User getBuyer() {
        return buyer;
    }

    public void setBuyer(User buyer) {
        this.buyer = buyer;
    }

    public Basket getBasket() {
        return basket;
    }

    public void setBasket(Basket basket) {
        this.basket = basket;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", time=" + time +
                ", status='" + status + '\'' +
                ", buyer=" + buyer +
                ", basket=" + basket +
                '}';
    }
}

