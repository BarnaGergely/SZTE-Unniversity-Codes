package application.controller;

import application.dao.ContactDAO;
import application.dao.UserDAO;
import application.model.Contact;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.ArrayList;

@Controller
public class ContactListController {

    @Autowired
    ContactDAO contactDAO;
    @Autowired
    UserDAO userDAO;

    @RequestMapping("/contactList")
    public String contactList(Model model) {
        model.addAttribute("pageTitle", "Kapcsolat lista");
        model.addAttribute("contactRequests", getContactRequests());
        return "ContactList";
    }

    public ArrayList<Contact> getContactRequests(){
        ArrayList<Contact> contacts = new ArrayList<>();
        contacts = contactDAO.getContactAll();
        return contacts;
    }

    @PostMapping(value = "/deleteContact/{id}")
    public String deleteContact(@PathVariable("id") int id){
        contactDAO.deleteContact(id);
        return "redirect:/contactList";
    }

}
