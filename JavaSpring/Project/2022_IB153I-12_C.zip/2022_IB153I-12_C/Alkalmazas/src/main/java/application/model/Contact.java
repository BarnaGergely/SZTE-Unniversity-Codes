package application.model;

public class Contact {
    int id;
    String username;
    String email;
    String message;

    public Contact() {
    }

    public Contact(String username, String email, String message) {
        this.username = username;
        this.email = email;
        this.message = message;
    }

    public Contact(int id, String username, String email, String message) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.message = message;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getMessage() {
        return message;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
