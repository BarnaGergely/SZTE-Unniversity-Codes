package application.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import application.model.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import application.model.User;

@Repository
public class UserDAO extends JdbcDaoSupport {

    @Autowired
    BCryptPasswordEncoder passwordEncoder;

    @Autowired
    DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public void insertUser(User user){
        String sql1 = "SELECT * FROM webshopdb.user WHERE webshopdb.user.username=?";
        boolean nemjo=true;
        List < Map < String, Object >> rows = getJdbcTemplate().queryForList(sql1,user.getUsername());

        if (rows.isEmpty()){
            String sql = "INSERT INTO webshopdb.user(username, password, email, firstname, surename, phoneNumber, age, country, city, zipCode, address, isAdmin) VALUES (?,?,?,?,?,?,?,?,?,?,?,false )";
            assert getJdbcTemplate() != null;
            getJdbcTemplate().update(sql, user.getUsername(),passwordEncoder.encode(user.getPassword()),user.getEmail(),user.getFirstName(),user.getSurName(),user.getPhoneNumber(),user.getAge(), user.getAddress().getCountry(), user.getAddress().getCity(), user.getAddress().getZipCode(), user.getAddress().getStreetHouseNumber());
        /*sql = "INSERT INTO webshop.basket(user_userid) VALUES (?)";
        assert getJdbcTemplate() != null;
        getJdbcTemplate().update(sql,this.getUserByUsername(user.getUsername()).getId());*/
        }


    }

    public void updateUser(int id,String username, String password, String newPassword1,String newPassword2, String email, String firstName, String surName, String phoneNumber, int age, String country, String city, int zipCode, String address) throws Exception {
        if (newPassword1.equals(newPassword2) || passwordEncoder.encode(password).equals(getUserById(id).getPassword())){
            String sql = "UPDATE webshopdb.user SET username='"+username+"', password='"+passwordEncoder.encode(newPassword1)+"', email='"+email+"', firstName='"+firstName+"', sureName='"+surName+"', phoneNumber='"+phoneNumber+"', age='"+age+"', country='"+country+"', city='"+city+"',zipCode='"+zipCode+"', address='"+address+"' WHERE userid="+id;
            getJdbcTemplate().update(sql);
        }

    }
    public void deleteUser(int id) {
        String sql = "DELETE FROM webshopdb.user WHERE userid=" + id;
        getJdbcTemplate().update(sql);
    }
    public User getUserById(int id){
        String sql = "SELECT * FROM webshopdb.user WHERE userid=?";
        List < Map < String, Object >> rows = getJdbcTemplate().queryForList(sql, id);
        List < User > result = new ArrayList < User > ();
        for (Map < String, Object > row: rows) {
            User user = new User();
            user.setId((Integer) row.get("userid"));
            user.setUsername((String) row.get("username"));
            user.setPassword((String) row.get("password"));
            user.setEmail((String) row.get("email"));
            user.setFirstName((String) row.get("firstName"));
            user.setSurName((String) row.get("sureName"));
            user.setPhoneNumber((String) row.get("phoneNumber"));
            user.setAge((int) row.get("age"));
            user.setAdmin((boolean) row.get("isAdmin"));

            Address address=new Address((String) row.get("country"),(String) row.get("city"),(int) row.get("zipCode"),(String) row.get("address"));
            user.setAddress(address);

            result.add(user);
        }
        return result.get(0);
    }
    public User getUserByUsername(String username){
        String sql = "SELECT * FROM webshopdb.user WHERE username=?";
        List < Map < String, Object >> rows = getJdbcTemplate().queryForList(sql, username);

        List < User > result = new ArrayList < User > ();
        for (Map < String, Object > row: rows) {
            User user = new User();
            user.setId((Integer) row.get("userid"));
            user.setUsername((String) row.get("username"));
            user.setPassword((String) row.get("password"));
            user.setEmail((String) row.get("email"));
            user.setFirstName((String) row.get("firstName"));
            user.setSurName((String) row.get("sureName"));
            user.setPhoneNumber((String) row.get("phoneNumber"));
            user.setAge((int) row.get("age"));
            user.setAdmin((boolean) row.get("isAdmin"));

            Address address=new Address((String) row.get("country"),(String) row.get("city"),(int) row.get("zipCode"),(String) row.get("address"));
            user.setAddress(address);

            result.add(user);
        }
        return result.get(0);
    }
}
