package application.dao;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import application.model.Address;
import application.model.Contact;
import application.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import application.model.User;

@Repository
public class ContactDAO extends  JdbcDaoSupport{

    @Autowired
    DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public void deleteContact(int id) {
        String sql = "DELETE FROM webshopdb.Contact WHERE contactid=" + id;
        getJdbcTemplate().update(sql);
    }
    public void insertContact(Contact contact) {
        String sql = "INSERT INTO webshopdb.Contact(userName,userEmail,message) VALUES (?,?,?)";
        if(contact.getMessage() != ""){
            getJdbcTemplate().update(sql, contact.getUsername(),contact.getEmail(),contact.getMessage());
        }

    }

    public ArrayList getContactAll(){
        String sql = "SELECT * FROM webshopdb.contact";
        List<Map< String, Object >> rows = getJdbcTemplate().queryForList(sql);
        ArrayList<Contact> result = new ArrayList<Contact>();
        for (Map < String, Object > row: rows) {
            Contact contact = new Contact();
            contact.setId((int) row.get("contactid"));
            contact.setUsername((String) row.get("userName"));
            contact.setEmail((String) row.get("userEmail"));
            contact.setMessage((String) row.get("message"));
            result.add(contact);
        }
        return result;
    }

}
