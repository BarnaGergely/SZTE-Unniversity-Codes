# Tesztjegyzőkönyv-Belépés, regisztráció, adatok változtatása

Az alábbi tesztdokumentum a Webshop projekthez tartozó 9.4.8. Felhasználói munkamenet tesztelése (regisztráció, bejelentkezés, adatok módosítása) (TP, TC, TR) funkcióihoz készült. Felelőse: Illés Milán 

## 1. Teszteljárások (TP)

### 1.1. Belépés funkció tesztelése
- Azonosító: TP-01
- Tesztesetek: TC-01, TC-02, TC-03
- Leírás: Belépés funkció tesztelése
    0. lépés: Nyissuk meg a weblapot, és lépjünk a belépés fülre
    1. lépés: Az 'Felhasználónév' szövegbeviteli mezőbe írjunk be a 'felhasznalonev' felhasználónevet
    2. lépés: Az 'Jelszó' szövegbeviteli mezőbe írjunk be a 'jelszo' jelszót
    3. lépés: Nyomjuk meg az 'Belépés' gombot 
    4. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: Bejelentkezés megtörténik, a funkciók elérhetőek lesznek

### 1.2. Regisztráció funkció tesztelése
- Azonosító: TP-02
- Tesztesetek: TC-01, TC-02, TC-03
- Leírás: Regisztráció funkció tesztelése
    0. lépés: Nyissuk meg a weblapot, és lépjünk a belépés fülre, majd váltsunk a regisztrációra
    1. lépés: Az 'Felhasználónév' szövegbeviteli mezőbe írjunk be a 'felhasznalonev' szöveget
    2. lépés: Az 'Vezetéknév' szövegbeviteli mezőbe írjunk be a 'vezeteknev' szöveget
    3. lépés: Az 'Keresztnev' szövegbeviteli mezőbe írjunk be a 'keresztnev' szöveget
    4. lépés: Az 'Jelszó' szövegbeviteli mezőbe írjunk be a 'jelszo' szöveget
    5. lépés: Az 'Email' szövegbeviteli mezőbe írjunk be a 'email' szöveget
    6. lépés: Az 'Telefon' szövegbeviteli mezőbe írjunk be a 'telefon' szöveget
    7. lépés: Az 'Kor' szövegbeviteli mezőbe írjunk be a 'kor' számot
    8. lépés: Nyomjuk meg az 'Resgisztráció' gombot 
    9. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: A regisztráció sikeres, lértrejön az új felhasználó
    
### 1.3. Módosítás funkció tesztelése
- Azonosító: TP-03
- Tesztesetek: TC-01, TC-02
- Leírás: Belépés funkció tesztelése
    0. lépés: Nyissuk meg a weblapot, és lépjünk a Profil fülre
    1. lépés: Az 'Felhasználónév' szövegbeviteli mezőbe írjunk be a 'uj_felhasznalonev' felhasználónevet
    2. lépés: Az 'Régi jelszó' szövegbeviteli mezőbe írjunk be a 'jelszo' jelszót
    3. lépés: Az 'Új jelszó' szövegbeviteli mezőbe írjunk be a 'uj_jelszo' jelszót
    4. lépés: Az 'Jelszó újra' szövegbeviteli mezőbe írjunk be a 'uj_jelszo' jelszót
    5. lépés: Nyomjuk meg az 'Mentés' gombot 
    6. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: Módosítás megtörténik, a felhasználónév mostantól 'uj_felhasznalonev', a jelszo pedig az 'uj_jelszo'

## 2. Teszesetek (TC)

### 2.1. Összeadás funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: Belépés funkció tesztelése 
- Bemenet: 'felhasznalonev' = user ; 'jelszo' = user 
- Művelet: nyomjuk meg az 'Belépés' gombot 
- Elvárt kimenet: Bejelentkezés megtörténik, a funkciók elérhetőek lesznek a user felhasználóval

#### 2.1.2. TC-02
- TP: TP-01
- Leírás: Belépés funkció tesztelése
- Bemenet: 'felhasznalonev' = user2 ; 'jelszo' = user 
- Művelet: nyomjuk meg az 'Belépés' gombot 
- Elvárt kimenet: az eredmény mező tartalma: Bejelentkezés nem történik meg, nem létezik ilyen nevű felhasználó

#### 2.1.2. TC-03
- TP: TP-01
- Leírás: Belépés funkció tesztelése
- Bemenet: 'felhasznalonev' = user ; 'jelszo' = user1234 
- Művelet: nyomjuk meg az 'Belépés' gombot 
- Elvárt kimenet: az eredmény mező tartalma: Bejelentkezés nem történik meg, a felhasználóhoz nem megfelelő jelszó lett megadva

### 2.2. Regisztráció funkció tesztelése

#### 2.2.1. TC-01
- TP: TP-02
- Leírás: Regisztráció funkció tesztelése
- Bemenet: 'Felhasználónév'='milan', 'Vezetéknév='Illés', 'Keresztnev'='Milán', 'Jelszó'='1234', 'Email'='illes.milan@gmail.com', 'Telefon'=36705469438, 'Kor'=20
- Művelet: nyomjuk meg az 'Regisztráció' gombot 
- Elvárt kimenet: az eredmény mező tartalma: Regisztráció sikeres, létrejön az új felhasználó

#### 2.2.1. TC-02
- TP: TP-02
- Leírás: Regisztráció funkció tesztelése
- Bemenet: 'Felhasználónév'='', 'Vezetéknév='Illés', 'Keresztnev'='', 'Jelszó'='1234', 'Email'='illes.milan@gmail.com', 'Telefon'=36705469438, 'Kor'=20
- Művelet: nyomjuk meg az 'Regisztráció' gombot 
- Elvárt kimenet: az eredmény mező tartalma: Regisztráció sikertelen, nincsen minden mező kitöltve

#### 2.2.1. TC-03
- TP: TP-02
- Leírás: Regisztráció funkció tesztelése
- Bemenet: 'Felhasználónév'='milan', 'Vezetéknév='Illés', 'Keresztnev'='Milán', 'Jelszó'='1234', 'Email'='illes.milan@gmail.com', 'Telefon'=36705469438, 'Kor'='husz'
- Művelet: nyomjuk meg az 'Regisztráció' gombot 
- Elvárt kimenet: az eredmény mező tartalma: Regisztráció sikertelen, HIBA(kor-hoz nem szám van megadva)

### 2.3. Módosítás funkció tesztelése

#### 2.3.1 TC-01
TP: TP-03
- Leírás: Módosítás funkció tesztelése
- Bemenet: 'Felhasználónév'='user2', 'Régi jelszó'='user', 'Új jelszó'='user1234', 'Jelszó újra'='user1234'
- Művelet: nyomjuk meg az 'Mentés' gombot 
- Elvárt kimenet: az eredmény mező tartalma: Módosítás sikeres, a Felhasználónév mostantól az 'uj_felhasználónév'

#### 2.3.2 TC-02
TP: TP-03
- Leírás: Módosítás funkció tesztelése
- Bemenet: 'Felhasználónév'='user2', 'Régi jelszó'='', 'Új jelszó'='user1234', 'Jelszó újra'='user1234'
- Művelet: nyomjuk meg az 'Mentés' gombot 
- Elvárt kimenet: az eredmény mező tartalma: Módosítás sikeres, nem lett kitöltve minden kötelező mező


## 3. Tesztriportok (TR)

### 3.1. Belépés funkció tesztelése

#### 3.1.1. TR-01 (TC-01)
- TP: TP-01
    1. lépés: user-t beírtam
    2. lépés: user-t beírtam 
    3. lépés: a gomb egyszeri megnyomás után inaktív lett
    4. lépés: helyes eredményt kaptam (Belépés megtörtént, funkciók megjelentek)
    

#### 3.1.2. TR-02 (TC-02)
- TP: TP-01
    1. lépés: user2-t beírtam
    2. lépés: user-t beírtam 
    3. lépés: a gomb egyszeri megnyomás után inaktív lett
    4. lépés: helyes eredményt kaptam (Belepés sikertelen, helytelen felhasználó lett megadva)

#### 3.1.2. TR-03 (TC-03)
- TP: TP-01
    1. lépés: user-t beírtam
    2. lépés: user1234-t beírtam 
    3. lépés: a gomb egyszeri megnyomás után inaktív lett
    4. lépés: helyes eredményt kaptam (Belepés sikertelen, helytelen jelszó lett megadva)

### 3.2. Regisztráció funkció tesztelése

#### 3.2.1. TR-01 (TC-01)
- TP: TP-02
    1. lépés: milan-t beírtam
    2. lépés: Illés-t beírtam 
    3. lépés: Milán-t beírtam 
    4. lépés: 1234-et beírtam 
    5. lépés: illes.milan@gmail.com-ot beírtam 
    6. lépés: 36705469438-at beírtam 
    7. lépés: 20-at beírtam 
    8. lépés: a gomb egyszeri megnyomás után inaktív lett
    9. lépés: helyes eredményt kaptam (Regisztráció sikeres, az új felhasználó létrejött)

#### 3.2.2. TR-02 (TC-02)
- TP: TP-02
    1. lépés: felhasznalonev-et üresen hagytam
    2. lépés: Illés-t beírtam 
    3. lépés: keresztnevet-et üresen hagytam 
    4. lépés: 1234-et beírtam 
    5. lépés: illes.milan@gmail.com-ot beírtam 
    6. lépés: 36705469438-at beírtam 
    7. lépés: 20-at beírtam 
    8. lépés: a gomb egyszeri megnyomás után inaktív lett 
    9. lépés: helyes eredményt kaptam (Regisztráció sikertelen, nincsen minden mező kitöltve)

#### 3.2.3. TR-03 (TC-03)
- TP: TP-02
    1. lépés: milan-t beírtam
    2. lépés: Illés-t beírtam 
    3. lépés: Milán-t beírtam
    4. lépés: 1234-et beírtam 
    5. lépés: illes.milan@gmail.com-ot beírtam 
    6. lépés: 36705469438-at beírtam 
    7. lépés: husz-at beírtam 
    8. lépés: a gomb egyszeri megnyomás után inaktív lett 
    9. lépés: helyes eredményt kaptam (Regisztráció sikertelen, HIBA(kor-hoz nem szám van megadva))

### 3.3. Regisztráció funkció tesztelése

#### 3.3.1. TR-01 (TC-01)
- TP: TP-01
    1. lépés: user2-t beírtam
    2. lépés: user-t beírtam
    3. lépés: user1234-t beírtam 
    4. lépés: user1234-t beírtam 
    5. lépés: a gomb egyszeri megnyomás után inaktív lett
    6. lépés: helyes eredményt kaptam (Módosítás sikeres, a felhasználónév a 'user2' és a jelszó pedig a 'user1234')

#### 3.3.2. TR-02 (TC-02)
- TP: TP-01
    1. lépés: user2-t beírtam
    2. lépés: nem irtam be a régi jelszót
    3. lépés: user1234-t beírtam 
    4. lépés: user1234-t beírtam 
    5. lépés: a gomb egyszeri megnyomás után inaktív lett
    6. lépés: helyes eredményt kaptam (Módosítás sikertelen, nem lett kitöltve minden kötelező mező)


    