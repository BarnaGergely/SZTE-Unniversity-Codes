# Tesztjegyzőkönyv - Admin

Az alábbi tesztdokumentum a Webáruház projekthez tartozó 9.4.9. Termék oldal tesztelése különféle felhasználó jogok alatt funkcióihoz készült. Felelőse: Herczeg Dávid



## 1. Teszteljárások (TP)

### 1.1. Rendelések megtekintésének tesztelése
- Azonosító: TP-01
- Tesztesetek: TC-01
- Leírás: Rendelések megtekintése
    1. lépés: Lépjünk be admin jogosultságú felhasználóval
    2. lépés: Menjünk a rendelések oldalra

## 2. Tesztesetek (TC)

### 2.1. Rendelések megtekintésének tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: Rendelések megtekintése
- Bemenet: -
- Művelet: -
- Elvárt kimenet: A rendelések listázva lesznek.

## 3. Tesztriportok (TR)

### 3.1. Rendelések megtekintésének tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-01
  Az oldal megnyílik. Kilistázódnak a rendelések. A tesztelés sikeres.

