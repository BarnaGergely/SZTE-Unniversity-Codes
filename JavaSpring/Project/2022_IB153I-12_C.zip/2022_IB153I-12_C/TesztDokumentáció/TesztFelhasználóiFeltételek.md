# Tesztjegyzőkönyv - Felhasználói munkamenet

Az alábbi tesztdokumentum a Webáruház projekthez tartozó 9.4.8. Felhasználói munkamenet tesztelése (regisztráció, bejelentkezés, adatok módosítása) funkcióihoz készült. Felelőse: Illés Milán


## 1. Teszteljárások (TP)

### 1.1. Regisztráció funkció tesztelése
- Azonosító: TP-01
- Tesztesetek: TC-01, TC-02
- Leírás: összeadás funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, és indítsuk el az regisztráció funkciót
    1. lépés: A username szövegbeviteli mezőbe írjuk be a usename szöveget
    2. lépés: A password szövegbeviteli mezőbe írjunk be a password szöveget
    3. lépés: A firstName szövegbeviteli mezőbe írjunk be a firstName szöveget
    4. lépés: A surName szövegbeviteli mezőbe írjunk be a surName szöveget
    5. lépés: Az email szövegbeviteli mezőbe írjunk be az email szöveget
    6. lépés: A phoneNumber szövegbeviteli mezőbe írjunk be a phoneNumber szöveget
    7.  lépés: Az age számbeviteli mezőbe írjunk be az age számot
    8. lépés: Nyomjuk meg az regisztráció gombot

### 1.2. Bejelentkezés funkció tesztelése
- Azonosító: TP-02
- Tesztesetek: TC-01, TC-02
- Leírás: bejelentkezés funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, és indítsuk el a bejelentkezés funkciót
    1. lépés: A username szövegbeviteli mezőbe írjuk be a usename szöveget
    2. lépés: A password szövegbeviteli mezőbe írjunk be a password szöveget
    3. lépés: Nyomjuk meg az bejelntkezés gombot

### 1.3. Profil funkció tesztelése
- Azonosító: TP-03
- Tesztesetek: TC-01
- Leírás: Profil funkció tesztelése
  0. lépés: Nyissuk meg az alkalmazást, lépjünk be egy felhasználóval és nyissuk meg a profil funkciót 

### 1.4. Profil módosítás funkció tesztelése
- Azonosító: TP-04
- Tesztesetek: TC-01, TC-02, TC-03
- Leírás: Profil módosítás funkció tesztelése
  0. lépés: Nyissuk meg az alkalmazást, lépjünk be egy felhasználóval és nyissuk meg a profil funkciót
  1. lépés: A username szövegbeviteli mezőbe írjuk be a usename szöveget
  2. lépés: A password szövegbeviteli mezőbe írjunk be a password szöveget
  3. lépés: A newPassword1 szövegbeviteli mezőbe írjunk be a newPassword1 szöveget
  4. lépés: A newPassword2 szövegbeviteli mezőbe írjunk be a newPassword2 szöveget
  5. lépés: A firstName szövegbeviteli mezőbe írjunk be a firstName szöveget
  6. lépés: A surName szövegbeviteli mezőbe írjunk be a surName szöveget
  7. lépés: Az email szövegbeviteli mezőbe írjunk be az email szöveget
  8. lépés: A phoneNumber szövegbeviteli mezőbe írjunk be a phoneNumber szöveget
  9. lépés: Az age szövegbeviteli mezőbe írjunk be az age számot
  10. lépés: A country szövegbeviteli mezőbe írjunk be a country szöveget
  11. lépés: A city szövegbeviteli mezőbe írjunk be a city szöveget
  12. lépés: A zipCode számbeviteli mezőbe írjunk be a zipCode számot
  13. lépés: Az adress szövegbeviteli mezőbe írjunk be az adress szöveget

## 2. Teszesetek (TC)

### 2.1. Regisztráció funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: regisztráció funkció tesztelése
- Bemenet: username = Tesztelőfiú ; password = test ; firstName = Test ; surName = Elek ; email = teszt.elek@gmail.com ; phoneNumber = 06301234567 ; age = 20
- Művelet: nyomjuk meg az regisztráció gombot
- Elvárt kimenet: A felhasználót átirányítja a profil oldalra. A felhasználót rögzíti az adatbázisban rejtett jelszóval.

#### 2.1.2. TC-02
- TP: TP-01
- Leírás: regisztráció funkció tesztelése
- Bemenet: username = user ; password = user ; firstName = Test ; surName = Elek ; email = teszt.elek@gmail.com ; phoneNumber = 06301234567 ; age = 20
- Művelet: nyomjuk meg az regisztráció gombot
- Elvárt kimenet: Vissza irányít a bejelentkezés oldalra

### 2.2. Bejelentkezés funkció tesztesetei

#### 2.2.1. TC-01
- TP: TP-02
- Leírás: bejelntkezés funkció tesztelése
- Bemenet: username = Tesztelőfiú ; password = test
- Művelet: nyomjuk meg az bejelentkezés gombot
- Elvárt kimenet: A felhasználót átirányítja a profil oldalra. Navigáción megjeleni a felhasználóneve és a profil, kapcsolat funkciók.

#### 2.2.2. TC-02
- TP: TP-02
- Leírás: bejelntkezés funkció tesztelése
- Bemenet: username = Tesztelőfiú123 ; password = test1
- Művelet: nyomjuk meg az bejelentkezés gombot
- Elvárt kimenet: Vissza irányít a bejelentkezés oldalra
### 2.3 Profil funkció tesztelése
#### 2.3.1 TC-01
- TP: TP-03
- Leírás: profil funkció tesztelése
- Bemenet: -
- Művelet: -
- Elvárt kimenet: Az adatbázisban a felhasználótól szereplő adatok megjelenítése az adott mezőben
### 2.4 Profil módosítás funkció tesztelése
#### 2.4.1 TC-01
- TP: TP-04
- Leírás: profil módosítás funkció tesztelése
- Bemenet: username = Tesztelőférfi ; password = test ; firstName = Test ; surName = Elek ; email = teszt.elek@gmail.com ; phoneNumber = 06301234567 ; age = 20 ; newPasword1 = teszt ; new Password2 = teszt ; country = Magyarország ; city = Szeged ; zipCode = 6700 ; adress = teszt utca 30
- Művelet: nyomjuk meg a módosít gombot
- Elvárt kimenet: A felhasználót átirányítja a profil oldalra. A felhasználót frissíti az adatbázisban modosított adatokkal

#### 2.4.2 TC-02
- TP: TP-04
- Leírás: profil módosítás funkció tesztelése
- Bemenet: username = Tesztelőférfi ; password = testtt ; firstName = Test ; surName = Elek ; email = teszt.elek@gmail.com ; phoneNumber = 06301234567 ; age = 20 ; newPasword1 = teszt1 ; new Password2 = teszt2 ; country = Magyarország ; city = Szeged ; zipCode = 6700 ; adress = teszt utca 30
- Művelet: nyomjuk meg a módosít gombot
- Elvárt kimenet: Hiba üzenet dobása: Nem megfelelő jelszó vagy az új jelszó megadása

#### 2.4.3 TC-03
- TP: TP-04
- Leírás: profil módosítás funkció tesztelése
- Bemenet: username = user ; password = test ; firstName = Test ; surName = Elek ; email = teszt.elek@gmail.com ; phoneNumber = 06301234567 ; age = 20 ; newPasword1 = teszt ; new Password2 = teszt ; country = Magyarország ; city = Szeged ; zipCode = 6700 ; adress = teszt utca 30
- Művelet: nyomjuk meg a módosít gombot
- Elvárt kimenet: Hiba üzenet dobása: Ez a felhasználónév már foglalt

## 3. Tesztriportok (TR)

### 3.1. Regisztráció funkció tesztriportjai

### 3.2. Bejelentkezés funkció tesztriportjai

### 3.3. Profil funkció tesztriportjai

### 3.4. Profil módosítása funkció tesztriportjai




