# Tesztjegyzőkönyv - Kapcsolat felvételi űrlap

Az alábbi tesztdokumentum a Webáruház projekthez tartozó 9.4.13. Kapcsolat felvételi űrlap tesztelése funkcióihoz készült.

Felelőse: Barna Gergely

## 1. Teszteljárások (TP)

### 1.1. Kapcsolat felvétele funkció tesztelése

- Azonosító: TP-01
- Tesztesetek: TC-01
- Leírás: Kapcsolat felvétele funkció tesztelése 0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be egy felhasználó jogú felhasználóval és indítsuk el a Kapcsolat funkciót
  1. lépés: A üzenet szövegbeviteli mezőbe írjuk be az özenet szövegét
  2. lépés: Nyomjuk meg a küldés gombot

### 1.2. Üzenetek megtekintése funkció tesztelése

- Azonosító: TP-02
- Tesztesetek: TC-01
- Leírás: Üzenetek megtekintése funkció tesztelése 0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be egy felhasználó jogú felhasználóval és indítsuk el az üzenetek funkciót
  1. lépés: Tekintsük meg a kiírt adatokat

### 1.3. Üzenet törlése funkció tesztelése

- Azonosító: TP-03
- Tesztesetek: TC-01
- Leírás: Üzenet törlése funkció tesztelése 0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be egy felhasználó jogú felhasználóval és indítsuk el az üzenetek funkciót
  1. lépés: Nyomjuk meg a törlés gombota a törölni kívánt sor mellett

## 2. Teszesetek (TC)

### 2.1. Kapcsolat felvétele funkció tesztelése

#### 2.1.1. TC-01

- TP: TP-01
- Leírás: Kapcsolat felvétele funkció tesztelése
- Bemenet: üzenet = "Ez egy üzenet"
- Művelet: nyomjuk meg a küldés gombot
- Elvárt kimenet: Eltűnnek az adatok az űrlapból és rögzíti az üzenetet az adatbázisban.

### 2.2. Üzenetek megtekintése funkció tesztelése

#### 2.2.1. TC-01

- TP: TP-02
- Leírás: Üzenetek megtekintése funkció tesztelése
- Bemenet: -
- Művelet: -
- Elvárt kimenet: A felhasználót átirányítja az üzenetek oldalra, ahol láthatjuk az adatbázisban szereplő üzeneteket.

### 2.4 Üzenet törlése funkció tesztelése

#### 2.3.1 TC-01

- TP: TP-03
- Leírás: Üzenet törlése funkció tesztelése
- Bemenet: -
- Művelet: nyomjuk meg a törlés gombot egy sor mellett
- Elvárt kimenet: A listából eltűnik az adott sor és törlődik a rekord az adatbázisból

## 3. Tesztriportok (TR)

### 3.1. Kapcsolat felvétele funkció tesztelése

- Minden testeset az elvárt működést hozta

### 3.2. Üzenetek megtekintése funkció tesztelése

- Minden testeset az elvárt működést hozta

### 3.3. Üzenet törlése funkció tesztelése

- Minden testeset az elvárt működést hozta
