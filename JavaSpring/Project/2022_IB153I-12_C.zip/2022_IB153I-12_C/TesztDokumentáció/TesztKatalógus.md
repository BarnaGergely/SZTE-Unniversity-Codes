# Tesztjegyzőkönyv - Katalógus

Az alábbi tesztdokumentum a Webáruház projekthez tartozó 9.4.10. Termék Katalógus tesztelése különféle felhasználó jogok alatt funkcióihoz készült. Felelőse: Földi Márk

## 1. Teszteljárások (TP)

### 1.1. Katalógus oldal funkció tesztelése
- Azonosító: TP-01
- Tesztesetek: TC-01
- Leírás: katalógus oldal funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, majd a katalógust

### 1.2.  Termék hozzáadás funkció tesztelése admin fehasználóval
- Azonosító: TP-02
- Tesztesetek: TC-01
- Leírás: termék hozzáaddás gombjának tesztelése
    0. lépés: Nyissuk meg az alkalmazást lépjünk be egy admin fehasználóval és kattuntsunk az Új termék létrehozása gombra

### 1.3.  Termék hozzáadás funkció tesztelése user fehasználóval
- Azonosító: TP-03
- Tesztesetek: TC-01
- Leírás: termék hozzáaddás url-jének tesztelése
  0. lépés: Nyissuk meg az alkalmazást lépjünk be egy user fehasználóval és érjuk at az url-ben a katalógust addProduct-ra


### 1.4.  Termék oldalra továbbítás funkció
- Azonosító: TP-04
- Tesztesetek: TC-01
- Leírás: termék oldalra való átlépés tesztelése
  0. lépés: Nyissuk meg az alkalmazást lépjünk be egy fehasználóval és nyomjunk rá bármelyik termék Tovább linkjére

## 2. Tesztesetek (TC)

### 2.1. Katalógus oldal funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: katalógus oldal funkció tesztelése
- Bemenet: -
- Művelet: -
- Elvárt kimenet: A termékek megjelennek az adatbázisból

### 2.2. Termék hozzáadás funkció tesztelése admin fehasználóval

#### 2.2.1. TC-01
- TP: TP-02
- Bemenet: -
- Művelet: Az Új termék létrehozása gombra kattintás
- Elvárt kimenet: az alkalmazás átirányítja a termék hozzáadás oldalra

### 2.3. Termék hozzáadás funkció tesztelése user fehasználóval

#### 2.3.1. TC-01
- TP: TP-03
- Bemenet: -
- Művelet: url átírása addProduct-ra
- Elvárt kimenet: az alkalmazás elszáll egy errorral mivel a felhasználó nem jogosult a termék hozzáadásához így az url-hez sem

### 2.4. Termék oldalra továbbítás funkció tesztelése

#### 2.4.1. TC-01
- TP: TP-04
- Bemenet: -
- Művelet: Termék tovább gombra kattintás
- Elvárt kimenet: az alkalmazás átirányít az adott termék oldalára

## 3. Tesztriportok (TR)

### 3.1. Katalógus oldal funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-01
  1. lépés: Az katalógus oldal helyesen megjelenik

### 3.2. Termék hozzáadás funkció tesztriportjai admin fehasználóval

#### 3.2.1. TR-01 (TC-01)
- TP: TP-02
  1. lépés: A termék hozzáadása oldal helyesen megjelenik

### 3.3. Termék hozzáadás funkció tesztriportjai user fehasználóval

#### 3.3.1. TR-01 (TC-01)
- TP: TP-03
  1. lépés: Az alkalmazás elszáll 403-as státusszal

### 3.4. Termék oldalra továbbítás funkció tesztriportjai

#### 3.4.1. TR-01 (TC-01)
- TP: TP-04
  1. lépés: A termék oldal helyesen megjelenik