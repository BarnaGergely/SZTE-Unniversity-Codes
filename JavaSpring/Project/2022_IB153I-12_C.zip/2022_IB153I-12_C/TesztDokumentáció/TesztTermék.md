# Tesztjegyzőkönyv - Termék

Az alábbi tesztdokumentum a Webáruház projekthez tartozó 9.4.9. Termék oldal tesztelése különféle felhasználó jogok alatt funkcióihoz készült. Felelőse: Bicok Norbert Dániel



## 1. Teszteljárások (TP)

### 1.1. Termék oldal funkció tesztelése
- Azonosító: TP-01
- Tesztesetek: TC-01
- Leírás: termék oldal funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, majd a kategóriát és nyissunk meg egy terméket

### 1.2. Termék hozzáadása funkció tesztelése
- Azonosító: TP-02
- Tesztesetek: TC-01
- Leírás: termék hozzáadása funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be egy adminnal, nyissuk meg a kategóriát majd nyojunk a termék hozzáadás gombra
    1. lépés: A productName szövegbeviteli mezőbe írjunk be a productName szöveget
    2. lépés: A productPrize számbeviteli mezőbe írjunk be a productPrize számot
    4. lépés: A productColor szövegbeviteli mezőbe írjunk be a productColor szöveget
    5. lépés: A productIMG filebeviteli mezőbe húzzuk be a productIMG filet
    6. lépés: A productSizeX számbeviteli mezőbe írjunk be a productSizeX számot
    7. lépés: A productSizeY számbeviteli mezőbe írjunk be a productSizeY számot
    8. lépés: A productSizeZ számbeviteli mezőbe írjunk be a productSizeZ számot
    9. lépés: A productDescription szövegbeviteli mezőbe írjunk be a productDescription szöveget
    10. lépés: A productType szövegbeviteli mezőbe írjunk be a productType szöveget

### 1.3. Termék módosítása funkció tesztelése

- Azonosító: TP-03
- Tesztesetek: TC-01
- Leírás: termék törlése funkció tesztelése
  0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be egy adminnal, nyissuk meg a kategóriákat, válasszuk ki a termékünket és mennyik el az oldalára.
  1. lépés: Ha elérkeztünk a termék oldalára, akkor nyomjuk meg a törlés gombot.


## 2. Tesztesetek (TC)

### 2.1. Termék oldal funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: termék oldal funkció tesztelése
- Bemenet: -
- Művelet: nyomjuk meg a kategóriákat az alkalmazás menüpontjánál
- Elvárt kimenet: A termék adataik megjelennek az adatbázisbol

### 2.2. Termék hozzáadás funkció tesztesetei

#### 2.2.1. TC-01
- TP: TP-02
- Leírás: termék hozzáadása funkció tesztelése
- Bemenet: productName = lil iphone ; productPrize = 2000 ; productColor = grey ; productSizeX = 10 ; productSizeY = 5 ; productSizeZ = 2 ; productDescription = Lil Iphone egy nagyon kicsi Iphone ; productType = phone ; productIMG = `a TesztDokumentációban szerplő test.png`
- Művelet: nyomjuk meg a feltöltés gombot
- Elvárt kimenet: Átirányít a kategóriák oldalra és a terméket feltőlti az adatbázisba.

### 2.3. Termék módosítása funkció tesztelései

#### 2.3.1. TC-01
- TP: TP-03
- Leírás: termék hozzáadása funkció tesztelése
- Bemenet: -
- Művelet: nyomjuk meg a törlés gombot
- Elvárt kimenet: Átirányít a kategóriák oldalra és a terméket kitörli az adatbázisból.
## 3. Tesztriportok (TR)

### 3.1. Termék oldal funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-01
  A választott termék megnyílik, és adatait kilistázza a felhasználónak.

### 3.2. Termék hozzáadás funkció tesztriportjai admin fehasználóval

#### 3.2.1. TR-01 (TC-01)
- TP: TP-02
  A választott terméket sikeresen hozzáadta az adatbázishoz.

### 3.3. Termék hozzáadás funkció tesztriportjai user fehasználóval

#### 3.3.1. TR-01 (TC-01)
- TP: TP-03
  A választott terméket siekeresen törölte az adatbázisból.


