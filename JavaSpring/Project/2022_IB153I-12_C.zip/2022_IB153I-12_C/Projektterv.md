# Webáruház Projektterv 2022

## 1. Összefoglaló

Ebben a projektben egy elektronikai árucikkeket forgalmazó webáruház megtervezése és lefejlesztése a célunk. A webáruház olyan online weboldal, ami termékeket vagy szolgáltatásokat értékesít. A vevők kiválaszthatják a megvásárolni kívánt termékeket és megrendelhetik azokat. A bolt tulajdonosok pedig láthatják és módosíthatják a rendeléseket. Célunk hogy kényelmesebbé tegyük a vásárlást és megkönnyítsük az eladók munkáját azzal hogy egységes, átlátható platformot hozunk létre, ahol megtekinthetik termékeiket és rendeléseiket.

## 2. Verziók

| Verzió | Szerző(k)                           | Dátum      | Státusz       | Megjegyzés                                                  |
| ------ | ----------------------------------- | ---------- | ------------- | ----------------------------------------------------------- |
| 0.1    | Barna Gergely, Illés Milán          | 2022-10-04 | Tervezet      | Legelső verzió                                              |
| 0.2    | Illés Milán, Bicok Norbert Dániel   | 2022-10-08 | Tervezet      | Felelősségek beosztása és Gantt chart létrehozása           |
| 0.3    | Barna Gergely                       | 2022-10-10 | Előterjesztés | A projekt menedzsere jónak találta                          |
| 1.0    |                                     | 2022-10-12 | Elfogadott    | 1. Mérföldkő teljesítve                                     |
| 1.1    | Barna Gergely, Bicok Norbert Dániel | 2022-10-15 | Tervezet      | Személyes felelősségek átszervezése, Gantt chart módosítása |
| 1.2    |                                     | 2022-10-18 | Előterjesztés | 2. mérföldkő további módosításai                            |
| 2.1    |                                     | 2022-10-25 | Elfogadott    | Leírások pontosítása a megjegyzések alapján                 |

Státusz osztályozás:

- Tervezet: befejezetlen dokumentum, a mérföldkő leadása előtti napokban
- Előterjesztés: a projekt menedzser bírálatával, a mérföldkő határidejekor
- Elfogadott: a megrendelő által elfogadva, a prezentáció bemutatásakor

## 3. A projekt bemutatása

Ez a projektterv a Webshop projektet mutatja be, mely 2022-09-20-től 2022-11-27-ig tart. A projekt célja, hogy egy olyan webes felületet biztosítsunk a megrendelő számára, ami a vevői számára egyszerű és kégyelmes vásárlási lehetőséget biztosít 24/7 időtartamban. Mindezért egy egyszerűen használható, átlátható és hatékonyan működő webalkalmazás fog felelni. A projekten hét fő fejlesztő fog dolgozni, az elvégzett feladatokat pedig négy alkalommal fogjuk prezentálni a megrendelőnek.

### 3.1. Rendszerspecifikáció

A rendszernek képesnek kell lennie arra, hogy adott cég által árusított termékeket illetve azok különböző adatait (kép, név, ár, leírás, attribútumok) feltüntesse, ezzel biztosítva a vevők tajékoztatását.
A projekt lehetőséget ad felhasználó készítésére is, amely lehetőséget ad a felhasználóknak adataik elmentésére. Emellett a webshop tulajdonosa egyszerűen és dinamikusan tudja bővíteni az árusított termékek listáját.  
A szűrő segítségével egyszerűen és könnyen lehet a termékek között keresni, így mindenki a saját igényeinek megfelelően választhat árucikket.
Minden funkció a megfelelő felhasználói jogosultság mellett használható, annak függvényében írható, olvasható vagy nem megtekinthető az adat.

### 3.2. Funkcionális követelmények

- Felhasználók (CRUD)
  - Felhasználók regisztrálhatnak és bejelentkezhetnek az oldalra
  - A felhasználók megadhatják szállítási adataikat, amik automatikusan betöltődnek rendeléskor
  - Felhasználók különböző jogosultsági szinttel rendelkezhetnek (admin, user, guest)
    - Admin: Rendelések és termékek kezelése
    - User: Vásárlás, Termékek megtekintése
    - Guest: Termékek megtekintése
  - A felhasználók módosíthatják személyes adataikat a grafikus felületen
  - Regisztrációkor bekért adatok:
    - Név
    - Felhasználónév
    - Jelszó
    - Email
    - Telefonszám
    - Életkor
- Termékek megtekintése és szűrése (Termék Katalógus)
  - A felhasználók megtekinthetik egy katalógusban a termékeket
  - Itt különféle szűrőket is alkalmazhatnak (pl.: csak bizonyos attribútummal rendelkező termékek jelenjenek meg)
  - Itt rendezhetik is a termékeket név és ár szerint
  - Az adminoknak ezen az oldalon megjelenik egy Termék létrehozása gomb is
- Termék oldalak
  - Minden termék rendelkezik egy egyedi oldallal, ahol megtekinthető róla egy kép, neve, ára, leírása, attribútumai (pl.: méret, szín, stb.)
  - Ezen az oldalon található egy gomb a kosárba helyezésre
    - A kosárba helyezésről kap valamilyen visszajelzést a felhasználó
  - Csak az adminok számára itt megjelennek plusz törlés és módosítás gombok is
- Termékek kezelése (CRUD)
  - Admin jogú felhasználók létrehozhatnak termékeket
  - Ezt a Termék Katalógus oldalon csak az adminok számára megjelenő létrehozás gombbal tehetik meg
  - Admin jogú felhasználók módosíthatnak és törölhetnek termékeket
    - Ezeket az adott termék oldalán, csak adminok számára megjelenő gombok segítségével tehetik meg
- Kosár megvalósítása (CRUD)
  - A user jogú felhasználók a megvásárolni kívánt termékeket kosárba rakhatják
  - A kosárban egy termékből akár több is lehet
  - A kosárban akár több féle termék is lehet
  - A felhasználók kivehetnek termékeket a kosarukból
  - A felhasználók láthatják a szállítás és fizetés díját a kosár oldalon
  - A vásárlás befejeztével a felhasználók megadhatják fizetési és szállítási információikat (pl.: Név, Email, Irányítószám, Utca, Házszám, Város, Ország, stb.)
  - A rendelés lezárásaként információkat kaphatnak pl.: a rendelés sikerességéről, a szállításról, az fizetésről (utánvét), a végösszegről, és az általuk megadott adatukról
- Rendelések oldal megvalósítása
  - Admin jogú felhasználók:
    - Törölhetik a rendeléseket
    - Listázhatják az összes rendelést
  - User jogú felhasználók:
    - Csak a saját rendeléseiket listázhatják
- Kapcsolatfelvételi űrlap biztosítása felhasználók számára
  - Megadandó adattagok:
    - Név (alapértelmezetten ki van töltve ha be van jelentkezve a felhasználó)
    - Emailcím (alapértelmezetten ki van töltve ha be van jelentkezve a felhasználó)
    - Üzenet
  - Admin felhasználók egy listában megtekinthetik a beérkezett üzeneteket

### 3.3. Nem funkcionális követelmények

- A kliens oldal platform- és böngészőfüggetlen legyen
- Reszponzív megjelenés
- Modern letisztult design
- Szenzitív adatokat biztonságosan tároljuk
- Kliens oldalon az interakcióra szolgáló gombok gyorsan és probléma mentesen hajtják végre feladatuk

## 4. Költség- és erőforrás-szükségletek

Az erőforrásigényünk összesen kb. 17 személynap/fő.

A rendelkezésünkre áll összesen 7 \* 70 = 490 pont.

## 5. Szervezeti felépítés és felelősségmegosztás

A projekt megrendelője Dr. Pflanzner Tamás. A Webáruház projektet a projektcsapat fogja végrehajtani, amely jelenleg hét fejlesztőből áll. A csapatban kezdő webfejlesztők találhatók, akik hatékony modern technológiák használatában jártasak.

- Bicok Norbert Dániel (1 év tapasztalat)
- Földi Márk (1 év tapasztalat)
- Herczeg Dávid (1 év tapasztalat)
- Barna Gergely (1 év tapasztalat)
- Illés Milán (1 év tapasztalat)
- Novák Ferenc (1 év tapasztalat)
- Vincze Imre Bence (1 év tapasztalat)

### 5.1 Projektcsapat

A projekt a következő emberekből áll:

|                                                                           | Név                  | E-mail cím (stud-os)            |
| ------------------------------------------------------------------------- | -------------------- | ------------------------------- |
| Megrendelő                                                                | Dr. Pflanzner Tamás  | tamas.pflanzner@inf.u-szeged.hu |
| Felelősségek: Projekt manager, A rendszer működési logikája, Dokumentáció | Barna Gergely        | h144988@stud.u-szeged.hu        |
| Felelősségek: Felhasználói felületek, Dokumentáció                        | Illés Milán          | h159060@stud.u-szeged.hu        |
| Felelősségek: Felhasználói felületek                                      | Vincze Imre Bence    | h166176@stud.u-szeged.hu        |
| Felelősségek: Prezentációk                                                | Novák Ferenc         | h771839@stud.u-szeged.hu        |
| Felelősségek: Adatbázis kapcsolatok megtervezése                          | Bicok Norbert Dániel | h146842@stud.u-szeged.hu        |
| Felelősségek: Költségségek és erőforrások                                 | Földi Márk           | h157700@stud.u-szeged.hu        |
| Felelősségek: Adatbázisok kezelése                                        | Herczeg Dávid        | h158605@stud.u-szeged.hu        |

## 6. A munka feltételei

### 6.1. Munkakörnyezet

A projekt a következő munkaállomásokat fogja használni a munka során:
-Munkaállomások: 7 db számítógép Windows 10-es vagy 11-es operációs rendszerrel

- Asztali számítógép (CPU: Ryzen 5 2600, RAM: 16GB, GPU: Nvidia GTX 1660)
- Asztali számítógép(CPU: Ryzen 7 2700, RAM: 16GB, GPU: Nvidia GTX 1050)
- Asztali számítógép (CPU: I5 9600KF, RAM: 16GB, GPU: Nvidia GTX 1660ti)
- Fali számítógép(CPU: Xtensa LX7, RAM: 0.00032768GB, GPU: NONE)
- Asus TUF FX505DT (CPU: Ryzen 5 3550H, Ram: 16 GB, GPU: Nvidia GTX 1650 )
- Lenovo Legion 5 82AU005MHV (CPU: Intel i5-10300H, RAM: 8GB, GPU: GTX 1650)
- HP Laptop (CPU: Intel i5-8250U, RAM: 16GB, GPU: Nvidia GeForce MX130)

A projekt a következő technológiákat/szoftvereket fogja használni a munka során:

- Heroku platformszolgáltatás
- Heroku által biztosított PostgreSQL adatbázisszerver
- Spring Boot (backend)
- Bootstrap (frontend)
- VSCode, IntelliJ IDEA IDE
- Git verziókövető (GitLab)
- Figma, Canva, Paint, Photoshop képszerkesztők

### 6.2. Rizikómenedzsment

| Kockázat                                  | Leírás                                                                                                                                                                                   | Valószínűség | Hatás |
| ----------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------ | ----- |
| Betegség                                  | Súlyosságtól függően hátráltatja vagy bizonyos esetekben teljes mértékben korlátozza a munkavégzőt, így az egész projektre kihatással van. Megoldás: a feladatok átcsoportosítása        | nagy         | erős  |
| Kommunikációs fennakadás a csapattagokkal | A csapattagok között nem elégséges az információ áramlás, nem pontosan, esetleg késve vagy nem egyértelműen tájékoztatjuk egymást. Megoldás: még gyakoribb megbeszélések és ellenőrzések | kis          | erős  |
| Technikai probléma                        | A kijelölt munkaállomások meghibásodása, ami a munkafolyamat késleltetését eredményezheti. Megoldás: Kabineti számítógép használata a probléma idejéig.                                  | közepes      | erős  |

## 7. Jelentések

### 7.1. Munka menedzsment

A munkát Barna Gergely koordinálja. Fő feladata, hogy folyamatosan egyeztessen a csapattagokkal az előrehaladásról és a fellépő problémákról, esetlegesen a megoldásban is segítséget nyújhat a projekt csúszásának elkerülése végett. További feladata a heti szinten tartandó csoportgyűlések időpontjának és helyszínének leszervezése, erről Discord-on tájékoztatja a projektcsapatot.

### 7.2. Csoportgyűlések

A projekt hetente ülésezik, hogy megvitassák az azt megelőző hét problémáit, illetve hogy megbeszéljék a következő hét feladatait. A megbeszélésről minden esetben memó készül.

#### 1. megbeszélés:

- Időpont: 2022.09.29.
- Hely: Discord
- Résztvevők: Mindenki
- Érintett témák: Projekt leírásának, feladatainak és eszközeinek specializálása
- Összefoglaló:
  - Végig néztük milyen feladatokat kell majd elvégeznünk a projektben és elkezdtük kitölteni a Projekttervet.
  - Jelenleg a fő feladat kitalálni nagyjából hogy fog működni a rendszer és kiosztani az ehhez szükséges feladatokat, hogy legközelebb megcsinálhassuk a beosztást.
  - Aktuális Feladatok:
    - Javítani a Projekttervet és a rendszer működésének utána járni (kell e nekünk api (kommunikáció a frontend és a backend között), hogy lehet automatikusan generálni oldalakat) - Gergely és akinek csak van hozzá kedve
    - GanttProjekt-et megtanulni használni - Norbi
    - Ha bármilyen ötleted vagy meglátásod van, ne tartsd magadban, dobd be DC-re.
  - Kövi Meeting: Vasárnap 17:00 ugyan itt

#### 2. megbeszélés:

- Időpont: 2022.10.02.
- Hely: Discord
- Résztvevők: Bicok Norbert Dániel, Földi Márk, Herczeg Dávid, Barna Gergely
- Érintett témák: Feladatok kiosztása, projekt részfeladatokra bontása
- Összefoglaló:
  - Ma feladatokat osztottunk ki és próbáltuk részfeladatokra bontani a projektet. Minden fenn van a Repo-ban.
  - Sok feladatnak még nincs gazdája. Ezeket még el kell vállalni valakinek. Nekem a legjobb az lenne, ha bele írnátok a Projekttervbe, ki melyiket vállalja. Vagy majd a gantt diagram készítésénél kimentünk egy táblázatot, amibe beírhatjátok a hiányzó feladatokra magatokat. De akár csinálhatunk erre még egy meeting-et is.
  - Aktuális Feladatok:
    - Feladatok beosztása (mindenki)
    - Elfelejtett feladatok felvitele (mindenki)
    - Grant diagram elkészítése (Norbi, vagy ha kell neki segítség, aki ráér)
    - Projektrev javítása (Gergő és akinek van hozzá kedve)
  - Kövi Meeting: Órán

#### 3. megbeszélés:

- Időpont: 2022.10.06.
- Hely: Discord
- Résztvevők: Illés Milán, Barna Gergely, Bicok Norbert Dániel, Földi Márk, Herczeg Dávid, Novák Ferenc
- Érintett témák: Feladatok kiosztása, funkciók újra gondolása
- Összefoglaló:
  - Véglegesítettük a specifikációkat és kiosztottuk a feladatokat.
  - Vincze Imre Bence Frontendes vagy, feladataidat a Projekttervben találod
  - Négy embernek van most csak feladata, amit jó lenne minél hamarabb befejezni, mert kemény lesz a jövőhét. Kitartást srácok!
  - A többiek barátkozhatnak a keretrendszerekkel, mert a következő mérföldkőre ismernünk kéne működésüket.
  - Kövi meeting: Órán, ha valami gáz van hétvégén

#### 4. megbeszélés:

- Időpont: 2022.10.19.
- Hely: Óra után
- Résztvevők: Illés Milán, Barna Gergely, Bicok Norbert Dániel, Földi Márk, Herczeg Dávid, Novák Ferenc
- Érintett témák: Első mérföldkő hiányosságainak pótlása,feladatok kiosztása

#### 5. megbeszélés:

- Időpont:
- Hely: Óra után
- Résztvevők: Illés Milán, Barna Gergely, Bicok Norbert Dániel, Földi Márk, Herczeg Dávid, Novák Ferenc
- Érintett témák: Első mérföldkő hiányosságainak pótlása,feladatok kiosztása

#### 6. megbeszélés:

- Időpont: 2022.11.03.
- Hely: Discord
- Résztvevők: Illés Milán, Barna Gergely, Bicok Norbert Dániel, Földi Márk, Herczeg Dávid, Vincze Imre Bence
- Érintett témák: Java Spring alapjai, feladatok kiosztása, elmaradt feladatok újra kalkulálása.


#### 7. megbeszélés:

- Időpont: 2022.11.12.
- Hely: Discord
- Résztvevők: Illés Milán, Barna Gergely, Bicok Norbert Dániel, Földi Márk, Herczeg Dávid, Vincze Imre Bence
- Érintett témák: státusz meeting és feladat összegzés

#### 8. megbeszélés:

- Időpont: 2022.11.28.
- Hely: Discord
- Résztvevők: Illés Milán, Barna Gergely, Bicok Norbert Dániel, Földi Márk, Herczeg Dávid, Vincze Imre Bence
- Érintett témák: utolsó mérföldkő előtti státusz meeting, tesztelés és hiba javítás

### 7.3. Minőségbiztosítás

Az elkészült terveket a terveken nem dolgozó csapattársak közül átnézik, hogy megfelel-e a specifikációnak és az egyes diagramtípusok összhangban vannak-e egymással. A meglévő rendszerünk helyes működését a prototípusok bemutatása előtt a tesztelési dokumentumban leírtak végrehajtása alapján ellenőrizzük és összevetjük a specifikációval, hogy az elvárt eredményt kapjuk-e. További tesztelési lehetőségek: unit tesztek írása az egyes modulokhoz vagy a kód közös átnézése (code review) egy, a vizsgált modul programozásában nem résztvevő csapattaggal. Szoftverünk minőségét a végső leadás előtt javítani kell a rendszerünkre lefuttatott kódelemzés során kapott metrikaértékek és szabálysértések figyelembevételével.
Az alábbi lehetőségek vannak a szoftver megfelelő minőségének biztosítására:

- Specifikáció és tervek átnézése (kötelező)
- Teszttervek végrehajtása (kötelező)
- Unit tesztek írása (választható)
- Kód átnézése (választható)

### 7.4. Átadás, eredmények elfogadása

A projekt eredményeit Dr. Pflanzner Tamás fogja elfogadni. A projektterven változásokat csak Dr. Pflanzner Tamás írásos kérés esetén Dr. Pflanzner Tamás engedélyével lehet tenni. A projekt eredményesnek bizonyul, ha specifikáció helyes és határidőn belül készül el. Az esetleges késések pontlevonást eredményeznek.
Az elfogadás feltételeire és beadás formájára vonatkozó részletes leírás a következő honlapon olvasható: https://okt.inf.szte.hu/rf1

### 7.5. Státuszjelentés

Minden leadásnál a projektmenedzser jelentést tesz a projekt haladásáról, és ha szükséges változásokat indítványoz a projektterven. Ezen kívül a megrendelő felszólítására a menedzser 3 munkanapon belül köteles leadni a jelentést. A gyakorlatvezetővel folytatott csapatmegbeszéléseken a megadott sablon alapján emlékeztetőt készít a csapat, amit a következő megbeszélésen áttekintenek és felmérik az eredményeket és teendőket. Továbbá gazdálkodnak az erőforrásokkal és szükség esetén a megrendelővel egyeztetnek a projektterv módosításáról.

## 8. A munka tartalma

### 8.1. Tervezett szoftverfolyamat modell és architektúra TODO

A szoftver fejlesztése során az iteratív fejlesztési modellt alkalmazzuk. A fejlesztés egy kezdetleges specifikációból indul ki és egy ennek megfelelő kezdeti rendszer kerül kifejlesztésre. Ez lesz a kiinduló rendszer. A rendszer specifikációjának további finomításával egymást követik a specifikáció, a fejlesztés és a validálás újabb ciklusai, mint iterációk, amelynek a végén kialakul a kívánt funkciókkal rendelkező rendszer.

A szoftver MVC alapú REST webszolgáltatásként működik. A szerver és a kliens függetlenek, csupán API végpontok segítségével kommunikálnak.

### 8.2. Átadandók és határidők

A főbb átadandók és határidők a projekt időtartama alatt a következők:

| Szállítandó |                Neve                 | Határideje |
| :---------: | :---------------------------------: | :--------: |
|     D1      |       Projektterv és útmutató       | 2022-10-12 |
|    P1+D2    | UML, DB, képernyőtervek és bemutató | 2022-10-26 |
|    P1+D3    |      Prototípus I. és bemutató      | 2022-11-16 |
|    P2+D4    |     Prototípus II. és bemutató      | 2022-11-30 |

## 9. Feladatlista

A következőkben a tervezett feladatok részletes összefoglalása található.

### 9.1. Projektterv (1. mérföldkő)

Ennek a feladatnak az a célja, hogy megvalósításhoz szükséges lépéseket, feladatokat az ütemzést és a felelősöket meghatározzuk.

Részfeladatai a következők:

#### 9.1.1. Projektterv kitöltése

Felelős: Illés Milán, Vincze Imre Bence, Barna Gergely, Novák Ferenc, Bicok Norbert Dániel, Földi Márk, Herczeg Dávid

Tartam: 3 nap

Erőforrásigény: 1 személynap

#### 9.1.2. Gantt diagram elkészítése

Felelős: Bicok Norbert Dániel

Tartam: 4 nap

Erőforrásigény: 0.5 személynap

#### 9.1.3. Költségvetés elkészítése

Felelős: Földi Márk

Tartam: 3 nap

Erőforrásigény: 0.8 személynap

#### 9.1.4. Projektterv véglegesítése (hiba javítás, hiányosságok pótlása)

Felelős: Illés Milán

Tartam: 4 nap

Erőforrásigény: 0.5 személynap

#### 9.1.5. Bemutató elkészítése

Felelős: Bicok Norbert Dániel

Tartam: 2 nap

Erőforrásigény: 0.5 személynap

### 9.2. UML és adatbázis tervek (2. mérföldkő)

Ennek a feladatnak az a célja, hogy a rendszerarchitektúrát, az adatbázist és webalkalmazás kinézetét megtervezzük.

Részfeladatai a következők:

#### 9.2.1. Megtanulni a Java Spring működésének a logikáját

Felelős: Minden Backend-es

Tartam: 4 nap

Erőforrásigény: 0 személynap

#### 9.2.2. Megtanulni a Bootstrap használatát és az általa kínált modulokkal megismerkedni

Felelős: Minden Frontend-es

Tartam: 4 nap

Erőforrásigény: 0 személynap

#### 9.2.3. Kiválasztani a Bootstrap melyik sablonját vagy moduljait fogjuk használni és megtanulni használatát

Felelős: Illés Milán

Tartam: 4 nap

Erőforrásigény: 1 személynap

#### 9.2.4. Use Case diagram

Felelős: Novák Ferenc

Tartam: 7 nap

Erőforrásigény: 3 személynap

#### 9.2.5. Class diagram

Felelős: Herczeg Dávid

Résztvevők: Barna Gergely

Tartam: 7 nap

Erőforrásigény: 4 személynap (2+2)

#### 9.2.6. Sequence diagram

Felelős: Földi Márk

Tartam: 7 nap

Erőforrásigény: 3 személynap

#### 9.2.7. Egyed-kapcsolat diagram adatbázishoz

Felelős: Bicok Norbert Dániel

Tartam: 7 nap

Erőforrásigény: 3 személynap

#### 9.2.8. Package diagram

Felelős: Novák Ferenc

Tartam: 7 nap

Erőforrásigény: 3 személynap

#### 9.2.9. Általános megjelenés, menük, footer képernyőterve és szín paletta létrehozása

Felelős: Illés Milán

Tartam: 7 nap

Erőforrásigény: 1 személynap

#### 9.2.10. Termék oldal képernyőterve

Felelős: Barna Gergely

Tartam: 7 nap

Erőforrásigény: 2 személynap

#### 9.2.11. Katalógus oldal képernyőterve

Felelős: Barna Gergely

Tartam: 7 nap

Erőforrásigény: 2 személynap

#### 9.2.12. Felhasználói munkamenethez kapcsolódó GUI képernyőterve (regisztráció)

Felelős: Vincze Imre Bence

Tartam: 7 nap

Erőforrásigény: 1 személynap

#### 9.2.13. Rendelések képernyőterve

Felelős: Vincze Imre Bence

Tartam: 7 nap

Erőforrásigény: 1 személynap

#### 9.2.14. Bemutató elkészítése

Felelős: Barna Gergely

Tartam: 3 nap

Erőforrásigény: 1 személynap

#### 9.2.15. Következő mérföldkő feladatainak pontos definiálása és ütemezése

Felelős: Barna Gergely

Tartam: 2 nap

Erőforrásigény: 1 személynap

### 9.3. Prototípus I. (3. mérföldkő)

Ennek a feladatnak az a célja, hogy egy működő prototípust hozzunk létre, ahol a vállalt funkcionális követelmények nagy része már prezentálható állapotban van.

Részfeladatai a következők:

#### 9.3.1. Adatbázisok létrehozása és kapcsolódás az adatbázishoz

Felelős: Bicok Norbert Dániel

Tartam: 4 nap

Erőforrásigény: 4 személynap

#### 9.3.2. Weboldal alapjainak üzleti logikájának létrehozása

Felelős: Földi Márk

Tartam: 5 nap

Erőforrásigény: 2 személynap

#### 9.3.3. Weboldal közös GUI alemeinek létrehozása (menü, footer, alap HTML, CSS és Bootstrap elemek)

Felelős: Illés Milán (100%)

Résztvevők: Barna Gergely (0%)

Tartam: 5 nap

Erőforrásigény: 3 személynap

#### 9.3.4. Felhasználói munkamenethez szükséges adatok létrehozása az adatbázisban (teszt felhasználók)

Felelős: Herczeg Dávid

Tartam: 3 nap

Erőforrásigény: 2 személynap

#### 9.3.5. Termékek létrehozása az adatbázisban

Felelős: Bicok Norbert Dániel

Tartam: 3 nap

Erőforrásigény: 3 személynap

#### 9.3.6. Felhasználói munkamenet üzleti logikája több jogosultsági szinttel (admin, user, guest, bejelentkezés, regisztráció, adatok módosítása)

Felelős: Földi Márk

Résztvevők: Barna Gergely (0,5pont)

Tartam: 5 nap

Erőforrásigény: 4 személynap

#### 9.3.7. Felhasználói munkamenethez kapcsolódó GUI megvalósítása (bejelentkezés, regisztráció, adatok módosítása)

Felelős: Vincze Imre Bence (50%)

Résztvevők: Földi Márk (50%)

Tartam: 4 nap

Erőforrásigény: 4 személynap

#### 9.3.8. Termék oldalhoz tartozó üzleti logika

Felelős: Novák Ferenc

Tartam: 7 nap

Erőforrásigény: 4 személynap

#### 9.3.9. Termék oldal GUI létrehozása

Felelős: Barna Gergely

Tartam: 4 nap

Erőforrásigény: 4 személynap

#### 9.3.10. Termék katalógushoz tartozó üzleti logika (listázás, szűrés, rendezés)

Felelős: Herczeg Dávid (0%)

Résztvevők: Novák Ferenc (100%)

Tartam: 7 nap

Erőforrásigény: 6 személynap

#### 9.3.11. Termék katalógushoz kapcsolódó GUI megvalósítása

Felelős: Barna Gergely

Tartam: 4 nap

Erőforrásigény: 4 személynap

#### 9.3.12. Termék létrehozásához tartozó üzleti logika megvalósítása

Felelős: Földi Márk

Tartam: 4 nap

Erőforrásigény: 3 személynap

#### 9.3.13. Termék létrehozásához tartozó GUI

Felelős: Illés Milán

Tartam: 5 nap

Erőforrásigény: 4 személynap

#### 9.3.14. Kosárhoz és pénztárhoz tartozó üzleti logika megvalósítása

Felelős: Bicok Norbert Dániel (50%)

Tartam: 7 nap

Erőforrásigény: 5 személynap

#### 9.3.15. Kosár és pénztár GUI megtervezése és megvalósítása

Felelős: Vincze Imre Bence (50%)

Tartam: 4 nap

Erőforrásigény: 4 személynap

#### 9.3.16. Kapcsolatfelvételi űrlap biztosítása felhasználók számára (üzleti logika)

Felelős: Földi Márk

Tartam: 4 nap

Erőforrásigény: 2 személynap

#### 9.3.17. Kapcsolatfelvételi űrlap biztosítása felhasználók számára GUI

Felelős: Illés Milán

Tartam: 4 nap

Erőforrásigény: 3 személynap

#### 9.3.18. Rendelések oldal üzleti logikájának létrehozása

Felelős: Herczeg Dávid

Tartam: 4 nap

Erőforrásigény: 3 személynap

#### 9.3.19. Rendelések oldal felhasználó felületének létrehozása

Felelős: Barna Gergely

Tartam: 4 nap

Erőforrásigény: 3 személynap

#### 9.3.20. Beérkező kapcsolat felvételi kérelmek listázása (üzenet oldal, ContactList) oldal üzleti logikájának létrehozása

Felelős: Novák Ferenc

Tartam: 4 nap

Erőforrásigény: 2 személynap

#### 9.3.21. Beérkező kapcsolat felvételi kérelmek listázása (üzenet oldal, ContactList) oldal felhasználó felületének létrehozása

Felelős: Vincze Imre Bence (50%)

Résztvevők: Novák Ferenc (50%)

Tartam: 4 nap

Erőforrásigény: 2 személynap

#### 9.3.22. Mappa rendszer létrehozás a repo-ban, sablon feltöltése, sablon működésének tesztelése, ha nem működik javítani

Felelős: Földi Márk

Tartam: 3 nap

Erőforrásigény: 1 személynap

#### 9.3.23. Szerver környezet beállítása és példa oldal feltöltése teszt képpen

Felelős: Novák Ferenc

Tartam: 2 nap

Erőforrásigény: 1 személynap

#### 9.3.24. Weboldal feltöltése a szerverre

Felelős: Novák Ferenc

Tartam: 2 nap

Erőforrásigény: 1 személynap

#### 9.3.25. Weboldal feltöltése a szerverre

Felelős: Novák Ferenc

Tartam: 2 nap

Erőforrásigény: 1 személynap

#### 9.3.26. Főoldal létrehozása

Felelős: Illés Milán

Tartam: 7 nap

Erőforrásigény: 1 személynap

#### 9.3.27. Tesztelési dokumentum (TP, TC)

Felelős: Földi Márk (Mindenki az általa fejlesztett részhez megírja, 0%, mert nem készült még el)

Tartam: 3 nap

Erőforrásigény: 1 személynap

#### 9.3.28. Bemutató elkészítése

Felelős: Barna Gergely

Tartam: 1 nap

Erőforrásigény: 1 személynap

### 9.4. Prototípus II. (4. mérföldkő)

Ennek a feladatnak az a célja, hogy az előző mérföldkő hiányzó funkcióit pótoljuk, illetve a hibásan működő funkciókat és az esetlegesen felmerülő új funkciókat megvalósítsuk. Továbbá az alkalmazás tesztelése is a mérföldkőben történik.

Részfeladatai a következők:

#### 9.4.1. Termékek módosításához és törléséhez kapcsolódó üzleti logika megvalósítása

Felelős: Bicok Norbert Dániel (50%)

Tartam: 5 nap

Erőforrásigény: 4 személynap

#### 9.4.2. Termékek módosításához és törléséhez kapcsolódó GUI megvalósítása

Felelős: Vincze Imre Bence - 0%

Tartam: 5 nap

Erőforrásigény: 4 személynap

#### 9.4.3. Pénztárhoz tartozó üzleti logika megvalósítása

Felelős: -----

Tartam: 4 nap

Erőforrásigény: 4 személynap

#### 9.4.4. Pénztárhoz tartozó GUI megvalósítása

Felelős: Illés Milán - 0%

Tartam: 3 nap

Erőforrásigény: 3 személynap

#### 9.4.5. Javított minőségű prototípus új funkciókkal

Felelős: Novák Ferenc

Tartam: 5 nap

Erőforrásigény: 2 személynap

#### 9.4.6. Javított minőségű prototípus javított funkciókkal

Felelős: Földi Márk

Tartam: 5 nap

Erőforrásigény: 3 személynap

#### 9.4.7. Javított minőségű prototípus a korábbi hiányzó funkciókkal

Felelős: Vincze Imre Bence

Tartam: 5 nap

Erőforrásigény: 1 személynap

#### 9.4.8. Felhasználói munkamenet tesztelése (regisztráció, bejelentkezés, adatok módosítása) (TP, TC, TR)

Felelős: Illés Milán

Tartam: 1 nap

Erőforrásigény: 1 személynap

#### 9.4.9. Termék oldal tesztelése különféle felhasználó jogok alatt (TP, TC, TR)

Felelős: Bicok Norbert Dániel

Tartam: 1 nap

Erőforrásigény: 1 személynap

#### 9.4.10. Termék Katalógus tesztelése különféle felhasználó jogok alatt (TP, TC, TR)

Felelős: Földi Márk

Tartam: 1 nap

Erőforrásigény: 1 személynap

#### 9.4.11. Admin speciális funkcióinak tesztelése (termékek kezelése, rendelések kezelése) (TP, TC, TR)

Felelős: Herczeg Dávid

Tartam: 1 nap

Erőforrásigény: 1 személynap

#### 9.4.12. Kostár és pénztár (TP, TC, TR)

Felelős: Novák Ferenc - 0%

Tartam: 1 nap

Erőforrásigény: 1 személynap

#### 9.4.13. Kapcsolatfelvételi űrlap tesztelése (TP, TC, TR)

Felelős: Barna Gergely

Tartam: 1 nap

Erőforrásigény: 1 személynap

#### 9.4.5. Javított minőségű prototípus új funkciókkal

Felelős: Herczeg Dávid

Tartam: 5 nap

Erőforrásigény: 2 személynap

#### 9.4.14. Bemutató elkészítése

Felelős: Barna Gergely

Tartam: 1 nap

Erőforrásigény: 1 személynap

## 10. Részletes időbeosztás

![image](./Gantt_Diagram/Webaruhaz_Projekt_Gantt_Diagram_V3.jpg)

## 11. Projekt költségvetés

### 11.1. Részletes erőforrásigény (személynap)

|         Név          | 1. leadás - Projektterv | 2. leadás - UML és adatbázis | 3. leadás - Prototípus I. | 4. leadás - Prototípus II. | Összesen |
| :------------------: | :---------------------: | :--------------------------: | :-----------------------: | :------------------------: | :------: |
|    Barna Gergely     |            1            |              10              |           12,5            |             2              |   25,5   |
|     Illés Milán      |           1.5           |              2               |            11             |             1              |   15.5   |
|  Vincze Imre Bence   |            1            |              2               |             6             |             1              |    10    |
|     Novák Ferenc     |            1            |              6               |            16             |             2              |    24    |
| Bicok Norbert Dániel |            2            |              3               |            10             |             3              |    18    |
|    Herczeg Dávid     |            1            |              2               |             5             |             3              |    11    |
|      Földi Márk      |           1.8           |              3               |           14,5            |             4              |   23.3   |

### 11.2. Részletes feladatszámok

|         Név          | 1. leadás - Projektterv | 2. leadás - UML és adatbázis | 3. leadás - Prototípus I. | 4. leadás - Prototípus II. | Összesen |
| :------------------: | :---------------------: | :--------------------------: | :-----------------------: | :------------------------: | :------: |
|    Barna Gergely     |            1            |              5               |             6             |             2              |    14    |
|     Illés Milán      |            2            |              2               |             4             |             2              |    10    |
|  Vincze Imre Bence   |            1            |              2               |             3             |             2              |    8     |
|     Novák Ferenc     |            1            |              2               |             7             |             2              |    12    |
| Bicok Norbert Dániel |            3            |              1               |             3             |             2              |    9     |
|    Herczeg Dávid     |            1            |              1               |             3             |             2              |    7     |
|      Földi Márk      |            2            |              1               |             7             |             2              |    12    |

### 11.3. Részletes költségvetés

Nem tudjuk hány pontunk van, így nem tudom kitölteni a táblázatot. E helyett írok egy képletet mindenkihez.

- Novák Ferenc => max 95% (bár nem kapott sok órát, de nagyon komoly munkát fektetett a 3. mérföldkőbe)
- Barna Gergely => max 95% (szinte mindenesként, akinek kellett besegített és össze fogta a csapatot)
- Földi Márk => max 95% (csendes lovas, aki mindig időre megcsinálta, amit rábíztunk)
- Bicok Norbert Dániel => 91% (A backend legnehezebb feladait rábíztuk, amivel kis csúszással ugyan de sikeresen megbirkózótt)
- Illés Milán => 85% (Frontend szíve lelke, aki nem vállalt sokat, de mindig időre megcsinálta a feladatát)
- Herczeg Dávid => 61% (Backend-es volt, meg tudta csinálni a feladatát, de nagyon sokszor kifutott a határidőből)
- Vincze Imre Bence => 51% (Frontend-es volt, aki nehezen, de bele tanult a Themeleaf-be)



|                  Név                   | 1. leadás - Projektterv | 2. leadás - UML és adatbázis | 3. leadás - Prototípus I. | 4. leadás - Prototípus II. | Összesen  |
| :------------------------------------: | :---------------------: | :--------------------------: | :-----------------------: | :------------------------: | :-------: |
| Maximálisan választható pontszám %-ban |         10% (7)         |           30% (21)           |         50% (35)          |          30% (21)          | 100% (70) |
|             Barna Gergely              |            4            |              19              |            32             |             15             |    70     |
|              Illés Milán               |            5            |              15              |            33             |             17             |    70     |
|           Vincze Imre Bence            |            4            |              14              |            31             |             21             |    70     |
|              Novák Ferenc              |            4            |              19              |            35             |             12             |    70     |
|          Bicok Norbert Dániel          |            7            |              16              |            35             |             12             |    70     |
|             Herczeg Dávid              |            4            |              16              |            31             |             19             |    70     |
|               Földi Márk               |            5            |              15              |            33             |             17             |    70     |

Szeged, 2022-11-14.
