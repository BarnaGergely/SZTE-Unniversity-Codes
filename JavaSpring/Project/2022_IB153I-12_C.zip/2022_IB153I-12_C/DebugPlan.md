﻿# Tesztelési terv
## Menetrend
#### 1 - Specifikáció összevetése a diagrammokkal és prototípussal
- Ellenőrizni, hogy a specifikációnak megfelelnek-e az elkészített diagrammok, ha nem akkor javítani.
- Átnézni, hogy a specifikációban megadott funkciók meg lettek-e valósítva a prototípusban.
#### 2 - Statikus tesztelés
- A forráskód átnézése (mindenki mást néz át mint amit csinált!)
#### 3 - Black-box tesztelés
- A futó program tesztelése (pl. ha rákattintuk a kapcsolat gombra, akkor a kapcsolat oldal nyílik-e meg vagy sem)
#### 4 - White-box tesztelés
- A forrás kód alapján teszteljök a programot. Lehet junit-tesztekkel vagy jegyzeteléssel (adott inputra mi történt)

## Tesztelési dokumentumok

- **TestProcedure - TP** (teszteljárás)
--   Részletes leírás a tesztesetek előkészítéséhez, végrehajtásához, kiértékeléséhez
--   Végrehajtandó lépések sorozata
--   Felsorolhatjuk a hozzá tartozó teszteseteket

- **TestCase - TC** (teszteset)
--   Teszteljárás alapján készül
--   Teszt inputok halmaza, végrehajtási feltételek, elvárt eredmények leírása

- **TestRiport - TR** (tesztriport)
--   Teszteset végrehajtásának eredménye (a teszt helyes/helytelen eredményt adott)

> Pontosabb leírás, példával 
> https://git-okt.sed.inf.szte.hu/markusa/rf1-pelda/blob/master/Tesztjegyzokonyv.md

## Miket kellene tesztelni

- **Regisztráció**
-- Csak megfelelő adatokat lehet-e bevinni
-- Fel kerül-e az adatbázisba az új felhasználó
-- Sikeres regisztráció után, be tud-e lépni a felhasználó

- **Profil oldal**
-- Be lehet-e lépni az oldalra
-- A felhasználó adatai megfelelően jelennek-e meg (karakterkódolás, névnél nem az email cím legyen)

- **Termék lista oldal**
-- Termékek megfelelően jelennek meg
-- Termékek különböző adatok szerinti sorba listázása

- **Termék oldal**
-- Termék adatai megfelelően jelennek meg
-- Jogosultság szerint jelennek-e meg a gombok
-- Terméket lehet-e szerkeszteni

- **Contact oldal**
-- Lehet-e üzenetet küldeni az adminnak
-- Ki lehet-e listázni az adminnak az üzeneteket

# Tesztelési aranyszabályok az okt.inf-ról
-   Az elvárt eredményt **mindig** specifikáljuk
-   Programozó ne tesztelje a saját programját    
-   **Minden** teszteredményét ellenőrizni kell    
-   Kivételes viselkedést is teszteljük    
-   Azt is igazoljuk, hogy egy program nem csinálja azt, amit nem kéne    
-   Teszteseteket meg kell tudni **ismételni**    
-   Ne feltételezzük, hogy hibátlan a program, **egy programban mindig vannak hibák**    
-   Hibák sokszor csoportosan jelentkeznek    
-   „Nezzünk körül” egy adott hiba esetén    
-   Tesztelés célja hibák megtalálása (a jó tesztadat az, amely előhozza)
