--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 15.0

-- Started on 2022-11-05 17:13:56

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 6 (class 2615 OID 16434)
-- Name: webshopdb; Type: SCHEMA; Schema: -; Owner: doadmin
--

CREATE SCHEMA webshopdb;


ALTER SCHEMA webshopdb OWNER TO doadmin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 213 (class 1259 OID 16466)
-- Name: Contact; Type: TABLE; Schema: webshopdb; Owner: doadmin
--

CREATE TABLE webshopdb."Contact" (
    "contactID" integer NOT NULL,
    "userName" character varying(100) NOT NULL,
    "userEmail" character varying(255) NOT NULL,
    message text NOT NULL
);


ALTER TABLE webshopdb."Contact" OWNER TO doadmin;

--
-- TOC entry 212 (class 1259 OID 16451)
-- Name: Order; Type: TABLE; Schema: webshopdb; Owner: doadmin
--

CREATE TABLE webshopdb."Order" (
    id integer NOT NULL,
    "basketID" integer NOT NULL,
    status text NOT NULL,
    "orderDate" date NOT NULL,
    "User_userID" integer NOT NULL
);


ALTER TABLE webshopdb."Order" OWNER TO doadmin;

--
-- TOC entry 214 (class 1259 OID 16473)
-- Name: Order_Product; Type: TABLE; Schema: webshopdb; Owner: doadmin
--

CREATE TABLE webshopdb."Order_Basket" (
    basket_id integer NOT NULL,
    order_id integer NOT NULL,
    quantity integer NOT NULL,
    status text NOT NULL,
    "priceSummary" double precision NOT NULL
);


ALTER TABLE webshopdb."Order_Basket" OWNER TO doadmin;

--
-- TOC entry 211 (class 1259 OID 16444)
-- Name: Product; Type: TABLE; Schema: webshopdb; Owner: doadmin
--

CREATE TABLE webshopdb."Basket" (
    id integer NOT NULL,
    "User_userID" integer NOT NULL,
);

ALTER TABLE webshopdb."Basket" OWNER TO doadmin;

CREATE TABLE webshopdb."Basket_Product" (
    product_id integer NOT NULL,
    basket_id integer NOT NULL,
    quantity integer NOT NULL,
    "priceSummary" double precision NOT NULL
);


ALTER TABLE webshopdb."Basket_Product" OWNER TO doadmin;


CREATE TABLE webshopdb."Product" (
    id integer NOT NULL,
    "productName" character varying(200) NOT NULL,
    "productType" character varying(100) NOT NULL,
    "productPrice" integer NOT NULL,
    "productDescription" text NOT NULL,
    "productIMG" text NOT NULL,
    "productColor" character varying NOT NULL,
    "productSizeX" double precision NOT NULL,
    "productSizeY" double precision NOT NULL,
    "productSizeZ" double precision NOT NULL
);

INSERT INTO webshopdb."Porduct" (`id`,`productName`,`productType`,`productPrice`,`productDescription`,`productIMG`,`productColor`,`productSizeX`,`productSizeY`,`productSizeZ`) VALUES
	(1,'Iphone 14','phone',569990,'Az új Iphone 14 6,3 inches, 5G-s kiadása. 6GB RAM-mal felszerelt, 256GB tárhellyel, 12MHz-es képfrissítéssel, Dual-lens-es, 12MP elő és hátoldali kamerával.','Adatbázis adatok/images/i14.png','black',78.1,160.8,7.8),
    (2,'Iphone 13','phone',389990,'Az új Iphone 13 6,1 inches, 5G-s kiadása. 6GB RAM-mal felszerelt, 256GB tárhellyel, 90Hz-es képfrissítéssel, Dual-lens-es, 12MP elő és hátoldali kamerával. ','Adatbázis adatok/images/i13.png','black',71.5,146.7,7.65),
    (3,'Samsung Galaxy S22','phone',309990,'Az új Samsung Galaxy S22 6,2 inches, 5G-s kiadása. 8GB RAM-mal felszerelt, 256GB tárhellyel, 90Hz-es képfrissítéssel, 18MP elő és hátoldali kamerával.','Adatbázis adatok/images/s22.png','black',70.6,146,7.6),
    (4,'Xiaomi 11T','phone',179990,'Az új Xiaomi 11T 5,9 inches, 5G-s kiadása. 6GB RAM-mal felszerelt, 128GB tárhellyel, 120Hz-es képfrissítéssel, 14MP előlapi és 24MP hátoldali kamerával.','Adatbázis adatok/images/11t.png','black',76.9,164.1,8.8),
	(5,'Lenovo Ideapad 3 82H801S7HV','laptop',239990,'Legújabb, 11. generációs I5-ös laptop processzorral felszerelt, 8GB RAM-mal, 258GB SSD-vel és NVIDIA videókártyával. 15.6 colos, IPS kijelzővel van felszerelve.','Adatbázis adatok/images/ideapad3.png','grey',359.2,236.5,19.9),
    (6,'Lenovo Legion 5 82JN000HHV','laptop',489900,'Legújabb gamer laptop, 11. generációs I5-ös laptop processzorral felszerelt, 8GB RAM-mal, 512GB SSD-vel és NVDIA RTX videókártyával. 16.6 colos, 120Hz, IPS kijelzővel van felszerelve.','Adatbázis adatok/images/legion5.png','black',359.2,236.5,19.9),
    (7,'ASUS ROG Strix G513IH-HN004W','laptop',416990,'Legújabb gamer, 4. generációs Ryzen 7 laptop processzorral felszerelt, 8GB RAM-mal, 512GB SSD-vel és NVDIA GTX videókártyával. 15.6 colos, 144Hz, IPS kijelzővel van felszerelve.','Adatbázis adatok/images/rogstrix.png','darkgrey',354,259,10.6),
    (8,'ASUS VivoBook S513EA-L12331','laptop',318990,'Legújabb, 11. generációs I5-ös laptop processzorral felszerelt, 8GB RAM-mal, 256GB SSD-vel és Intel integrált videókártyával. 15.6 colos, IPS kijelzővel van felszerelve.','Adatbázis adatok/images/vivobook.png','silver',359,235,17.9),
    (9,'AMD Ryzen 5 5600X Processor','pcComponent',114990,'A Ryzen 5 5600X egy hatmagos, 12 szálas processzor, 3,7 GHz-es alap órajellel és 4,6 GHz-es maximális teljesítménynöveléssel. Egymagos komplexumból épül fel, amely 32 MB L3 gyorsítótárral rendelkezik, amelyet a sajátjának hívhat.','Adatbázis adatok/images/r55600x.png','base',5.3,5.2,2.9),
    (10,'MSI A520M PRO Motherboard','pcComponent',419990,'AM4-es gamer alaplap, amely akár az 5. generációs Ryzen processzorokat is támogatja. 2 PCIe 4.0-ás porttal rendelkezik. 128GB maximális memória kezelés.','Adatbázis adatok/images/a520m.png','black',244,210,15),
    (11,'ASUS Dual GeForce RTX 3060 OC V2 VGA','pcComponent',225000,'Legújabb RTX 3000-es szériás videókártya. 12GB RAM-mal rendelkezik, melyek 1837 MHz-en dolgoznak.','Adatbázis adatok/images/rtx3060.png','black',200,123,38),
    (12,'Kingston FURY Beast','pcComponent',14990,'3200MHz-en dolgozó, cl16-os szabványú memória.','Adatbázis adatok/images/kingstonfury.png','black',133.35,41.24,7),
    (13,'HyperX Cloud II Gaming Headset','pcPeripherals',34990,'A HyperX Cloudot úgy építették, hogy egy rendkívül kényelmes, elképesztő hangzással rendelkező játék headset legyen. Sokat gondolkodtunk a HyperX aláírt memóriahab, a prémium műbőr, a szorítóerő és a súlyelosztás részletein, hogy olyan headsetet alkossunk, amely hosszú játékmeneteken keresztül is kényelmes. Nem csoda, hogy játékosok millióinak kedvelt játékheadsetjévé vált. Akár a versenyre szeretnél koncentrálni, akár a kedvenc játékaiddal szeretnél lazítani, a Cloud tökéletes lesz számodra.','Adatbázis adatok/images/cloud2.png','black',198,142,91),
    (14,'Logitech G Pro Mechanical Gaming Keyboard','pcPeripherals',42990,'A Romer-G Tactile mechanikus kapcsolók kifejezetten a profi szintű teljesítményt, érzékenységet és tartósságot szem előtt tartva készültek.  több-billentyűs bevitel azt jelenti, hogy az összetett parancsok végrehajtása mindig pontos. A 26 billentyű egyidejű érzékelésének köszönhetően szinte bármennyi billentyűt és módosítóbillentyűt, plusz a módosítóbillentyűket (Control, Alt, Shift) lenyomhat egyszerre tetszőleges sorrendben, és biztos lehet abban, hogy a rendszer mindet érzékeli.','Adatbázis adatok/images/g305.png','black',361,153,34),
    (15,'Logitech G305 LightSpeed Hero Gaming Mouse','pcPeripherals',19990,'A HERO a Logitech G által tervezett, forradalmian új optikai érzékelő kategóriájában a legjobb teljesítménnyel és akár 10-szer takarékosabb energiafelhasználással (az előző generációhoz viszonyítva). A HERO érzékelő kivételes pontosságot és állandó teljesítményt nyújt 200–12 000 DPI tartományban simítás, gyorsítás vagy szűrés nélkül. A G305 akár 5 profilt is tud menteni 5 DPI-szinttel, amelyek mindegyike a beépített memóriában található.','Adatbázis adatok/images/gpro.png','black',116.6,62.15,38.2),
    (16,'SPC Gear Endorphy Cordura Speed XL Mousepad','pcPeripherals',17990,'SPC Gear Endorphy szövet egérpad, mely vízlepergetős. Kontabilis minden lézeres vagy optikai egérrel.','Adatbázis adatok/images/spcgear.png','black',400,450.1,3),


ALTER TABLE webshopdb."Product" OWNER TO doadmin;

--
-- TOC entry 210 (class 1259 OID 16435)
-- Name: User; Type: TABLE; Schema: webshopdb; Owner: doadmin
--

CREATE TABLE webshopdb."User" (
    "userID" integer NOT NULL,
    "userName" character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    "firstName" character varying(75) NOT NULL,
    "sureName" character varying(75) NOT NULL,
    "phoneNumber" character varying(30) NOT NULL,
    age integer NOT NULL,
    country character varying(75) NOT NULL,
    city character varying(100) NOT NULL,
    "zipCode" integer NOT NULL,
    address character varying(100) NOT NULL,
    "isAdmin" boolean NOT NULL
);


ALTER TABLE webshopdb."User" OWNER TO doadmin;

--
-- TOC entry 215 (class 1259 OID 16488)
-- Name: User_userID_seq; Type: SEQUENCE; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE webshopdb."User" ALTER COLUMN "userID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME webshopdb."User_userID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 4201 (class 2606 OID 16472)
-- Name: Contact Contact_pkey; Type: CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."Contact"
    ADD CONSTRAINT "Contact_pkey" PRIMARY KEY ("contactID");


--
-- TOC entry 4203 (class 2606 OID 16477)
-- Name: Order_Product Order_Product_pkey; Type: CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."Order_Product"
    ADD CONSTRAINT "Order_Product_pkey" PRIMARY KEY (product_id, order_id);


--
-- TOC entry 4196 (class 2606 OID 16457)
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id, "User_userID");


--
-- TOC entry 4194 (class 2606 OID 16450)
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- TOC entry 4190 (class 2606 OID 16441)
-- Name: User User_pkey; Type: CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY ("userID");


--
-- TOC entry 4199 (class 2606 OID 16459)
-- Name: Order id_UNIQUE; Type: CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."Order"
    ADD CONSTRAINT "id_UNIQUE" UNIQUE (id);
    
ALTER TABLE ONLY webshopdb."Basket"
    ADD CONSTRAINT "id_UNIQUE" UNIQUE (id);


--
-- TOC entry 4192 (class 2606 OID 16443)
-- Name: User userName_UNIQUE; Type: CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."User"
    ADD CONSTRAINT "userName_UNIQUE" UNIQUE ("userName");


--
-- TOC entry 4197 (class 1259 OID 16465)
-- Name: fk_Order_User1_idx; Type: INDEX; Schema: webshopdb; Owner: doadmin
--

CREATE INDEX "fk_Order_User1_idx" ON webshopdb."Order" USING btree ("User_userID");


--
-- TOC entry 4204 (class 2606 OID 16460)
-- Name: Order fk_Order_User1; Type: FK CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."Order"
    ADD CONSTRAINT "fk_Order_User1" FOREIGN KEY ("User_userID") REFERENCES webshopdb."User"("userID");


--
-- TOC entry 4205 (class 2606 OID 16478)
-- Name: Order_Product fk_Product_has_Order_Order1; Type: FK CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."Order_Basket"
    ADD CONSTRAINT "fk_Basket_has_Order_Order1" FOREIGN KEY (order_id) REFERENCES webshopdb."Order"(id);


--
-- TOC entry 4206 (class 2606 OID 16483)
-- Name: Order_Product fk_Product_has_Order_Product1; Type: FK CONSTRAINT; Schema: webshopdb; Owner: doadmin
--

ALTER TABLE ONLY webshopdb."Order_Basket"
    ADD CONSTRAINT "fk_Basket_has_Order_Basket1" FOREIGN KEY (product_id) REFERENCES webshopdb."Product"(id);
    
    
ALTER TABLE ONLY webshopdb."Basket_Product"
    ADD CONSTRAINT "fk_Product_has_Basket_Basket1" FOREIGN KEY (basket_id) REFERENCES webshopdb."Basket"(id);
    
    
ALTER TABLE ONLY webshopdb."Basket_Product"
    ADD CONSTRAINT "fk_Product_has_Basket_Product1" FOREIGN KEY (product_id) REFERENCES webshopdb."Product"(id);


--
-- TOC entry 4351 (class 0 OID 0)
-- Dependencies: 4
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2022-11-05 17:13:59

--
-- PostgreSQL database dump complete
--

